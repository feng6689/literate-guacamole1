# 床旁生命体征异常检测系统（项目骨架）

面向 15 家医疗机构组成的区域医院网络，从床旁设备采集的 10 分钟聚合生命体征快照中识别真实生理恶化事件。项目目标是将规则报警系统的误报降低至少 65%，同时把真实异常命中率保持在 0.92 以上，主指标 Average Precision 达到 0.78。

当前仓库是**结构完整、算法待实现**的工程骨架：数据契约、配置、流水线编排、16 项交付物组件、在线服务与测试均已就位，所有算法方法以带 FP 编号的占位实现保留。

## 快速开始

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install -e .            # 可选；不安装时使用 PYTHONPATH=src

make check                  # 结构自检：62 个文件、22 个特征、16 项交付物
make test                   # unittest 全量测试
PYTHONPATH=src python -m vitals_anomaly check-structure   # 未安装本包时使用
vitals-anomaly check-structure                            # 已执行 pip install -e . 时可用
```

`make train`、`make evaluate`、`make audit`、`make serve` 当前会以退出码 2 提示“骨架尚未实现”，这是预期行为，不代表环境故障。

## 目录结构

```text
vitals-anomaly-detection/
├── pyproject.toml / requirements.txt / Makefile / .gitignore
├── configs/                 base.json、debug.json
├── docs/                    架构、数据契约、交付物清单
├── src/vitals_anomaly/
│   ├── constants.py         22 个特征契约与全部项目常量
│   ├── config.py            分节配置与 JSON 读写
│   ├── core.py              组件基类、异常、延迟导入
│   ├── context.py           DataBundle / PipelineContext
│   ├── manifest.py          62 个文件的权威清单
│   ├── registry.py          FP-01 ~ FP-16 注册表（惰性解析）
│   ├── data/                契约校验、患者级时间切分
│   ├── features/            预处理、交互矩阵、F 检验、多项式、折外编码、分布画像
│   ├── models/              Bagging、软投票、Pickle 工件包
│   ├── evaluation/          Hit Rate@K、学习曲线、跨机构、噪声鲁棒、公平性
│   ├── explain/             SHAP 全局/局部解释
│   ├── serving/             批量评分与漂移监测
│   ├── pipeline/            19 个阶段与编排器
│   ├── reporting/           JSON / Markdown 报告
│   └── cli.py               check-structure / train / evaluate / audit / serve
├── scripts/                 结构检查、合成数据、流水线快捷入口
├── tests/                   契约、配置、注册表、结构、流水线测试
├── data/raw/                原始数据落点（.gitkeep）
├── artifacts/               模型与工件落点（.gitkeep）
└── reports/                 报告落点（.gitkeep）
```

完整文件清单以 `src/vitals_anomaly/manifest.py` 中的 `PROJECT_FILES` 为准，`make check` 会逐个核对是否存在。

## 常用命令

| 命令 | 作用 | 当前状态 |
| --- | --- | --- |
| `make check` | 文件清单、特征契约、16 项交付物挂载自检 | 可用 |
| `make compile` | 编译 `src/scripts/tests` | 可用 |
| `make test` | unittest 全量测试 | 可用 |
| `make synth` | 生成 68,000 条合成记录 | 待实现 |
| `make train` | 训练与打包流水线 | 待实现 |
| `make evaluate` | 评估与分层报告 | 待实现 |
| `make audit` | 跨机构与公平性审计 | 待实现 |
| `make serve` | 在线评分与漂移监测 | 待实现 |

## 数据契约摘要

- 68,000 条记录，每条为 10 分钟聚合快照；15 家机构。
- 22 个模型输入特征：18 个数值型、1 个有序型（`consciousness_score`）、3 个类别型。
- 二值标签 `vitals_anomaly_flag`，正例率约 1.8%。
- 约 3% 传感器伪影、约 2% 标签噪声。
- `facility_id` 仅作分组与审计元数据，不进入模型；`vitals_delta_rate` 由预处理生成，不计入 22 个原始特征。

详见 [docs/data_contract.md](docs/data_contract.md)。

## 交付物

16 项交付物（FP-01 ~ FP-16）分别落在独立模块中，注册表统一登记模块路径、类名与入口方法；`check_registry()` 会解析并校验 `fp_id` 一致性。逐项说明见 [docs/deliverables.md](docs/deliverables.md)。

## 依赖与限制

- 运行时仅依赖 `numpy`、`pandas`，与当前环境已安装库一致；`scikit-learn`、`shap`、`matplotlib` 等未安装，骨架不在模块顶层导入它们。
- 后续实现算法时，如需引入上述库，应在对应方法内延迟导入，并在本节登记后再安装。
- 所有占位方法抛出 `ComponentNotImplementedError`，异常信息包含 `TODO(FP-xx)` 与验收要点，便于逐项填充。
- 骨架不声称任何模型效果；`AP 0.78`、`命中率 0.92` 均为待验证目标，不是当前实测结果。

## 推荐实现顺序

1. `data/`：合成数据 → 契约校验 → 患者级时间切分。
2. `features/`：预处理 → FP-01/02 交互矩阵 → FP-03 特征筛选 → FP-11 折外编码。
3. `models/`：FP-04 Bagging → FP-05 软投票 → FP-07 工件打包。
4. `evaluation/`：FP-06 指标 → FP-12 学习曲线 → FP-13 跨机构 → FP-14 噪声鲁棒 → FP-15 公平性。
5. `features/polynomial.py` FP-09、`explain/` FP-10、`serving/` FP-16。
6. 每完成一项，运行 `make check && make test`，并补充该项对应的验收证据。

## 验证现状

- `python -m compileall src scripts tests` 通过。
- 39 个包内模块可导入，无循环依赖。
- 16 项交付物全部可解析，`fp_id` 与登记一致。
- 19 个流水线阶段覆盖 FP-01 ~ FP-16。
- `make test` 覆盖契约、配置、注册表、文件清单、阶段计划与报告输出。
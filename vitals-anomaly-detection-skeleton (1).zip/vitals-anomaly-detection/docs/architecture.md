# 架构说明

## 分层

```text
CLI (cli.py)
  └── Pipeline (pipeline/runner.py, pipeline/stages.py)
        ├── Data      (data/schema.py, data/splitter.py)
        ├── Features  (features/preprocessor.py 及 FP 组件)
        ├── Models    (models/bagging.py, voting.py, persistence.py)
        ├── Evaluation(evaluation/*.py)
        ├── Explain   (explain/shap_explainer.py)
        ├── Serving   (serving/service.py, serving/drift.py)
        └── Reporting (reporting/report.py)
```

依赖方向自上而下，横向模块只依赖 `constants.py`、`config.py`、`core.py`、`context.py` 四个基础模块，不存在反向依赖。

## 基础模块职责

| 模块 | 职责 |
| --- | --- |
| `constants.py` | 22 个特征规格、数据规模、目标指标、阈值与分组定义；唯一常量来源 |
| `config.py` | 8 个分节配置、JSON 读写、路径/元组归一化、取值范围校验 |
| `core.py` | `DeliverableComponent` 基类、四类项目异常、延迟导入工具 |
| `context.py` | `DataBundle` 与 `PipelineContext`，承载数据、产物、指标与失败记录 |
| `manifest.py` | 62 个文件的权威清单与存在性核对 |
| `registry.py` | 16 项交付物的模块/类/方法登记，惰性解析并校验 `fp_id` |

## 数据流

1. `SchemaValidator.validate` 校验列、类型、范围与标签取值。
2. `TemporalSplitter.split` 按患者隔离、按时间顺序切分，禁止跨集合共享患者。
3. `Preprocessor.fit_transform` 只在训练集拟合，生成 `vitals_delta_rate`。
4. 特征层并行产出：FP-01/02 交互矩阵、FP-03 筛选结果、FP-09 多项式项、FP-11 折外编码、FP-08 分布画像。
5. 模型层训练 FP-04 Bagging 与 FP-05 软投票，FP-07 打包全部工件。
6. 评估层计算 FP-06 指标、FP-12 学习曲线、FP-13 跨机构、FP-14 噪声鲁棒与 FP-15 公平性。
7. FP-16 加载工件包提供批量评分，并用 PSI 监测漂移。
8. `ReportWriter` 输出 JSON 摘要与 Markdown 报告。

## 关键设计决策

- **机构列不入模**：`facility_id` 只用于切分、校准与公平性分组，避免模型学习机构编码形成代理泄漏；设备型号、采集时段、班次编码保留为特征，但列入 `LEAKAGE_SENSITIVE_FEATURES`，由 FP-11 检测代理性。
- **派生特征单列**：`vitals_delta_rate` 由 10 分钟相邻快照差分生成，必须在时间上只使用过去窗口，因此不计入 22 个原始特征。
- **注册表惰性解析**：`registry.py` 不在模块顶层导入组件，避免 `pipeline ↔ registry ↔ 组件` 的循环依赖，同时让结构自检可以逐项报错而不是整体崩溃。
- **占位异常可定位**：所有未实现方法抛出 `ComponentNotImplementedError`，消息内包含 `TODO(FP-xx)` 与验收要点，CLI 捕获后返回退出码 2。
- **依赖最小化**：运行时只依赖 numpy 与 pandas；算法库在方法内延迟导入，保证骨架在精简环境可编译、可导入、可测试。

## 错误与退出码

| 退出码 | 含义 |
| --- | --- |
| 0 | 成功，或结构自检全部通过 |
| 1 | 结构自检失败（文件缺失、契约不一致、交付物无法解析） |
| 2 | 配置非法，或调用了尚未实现的骨架方法 |
| 3 | 项目内可预期异常（如数据契约不满足） |

## 扩展点

- 新增交付物：在组件模块实现方法 → 在 `registry.DELIVERABLES` 登记 → 在 `pipeline/stages.py` 增加阶段 → 更新 `docs/deliverables.md`。
- 新增特征：修改 `constants.FEATURE_SPECS` 并同步 `N_INPUT_FEATURES`、数据契约文档与配置；`validate_feature_contract()` 会拦截数量、重复与范围错误。
- 新增配置：在 `config.py` 增加分节 dataclass，加入 `PipelineConfig` 字段，并同步 `configs/base.json`。
- 新增文件：必须同步 `manifest.PROJECT_FILES`，否则 `make check` 会报缺失。

## 测试策略

- 契约测试：特征数量、唯一性、类型分布、目标/分组列排除。
- 配置测试：两份示例配置、字典/JSON 往返、非法取值拦截。
- 注册表测试：16 项唯一、可解析、继承基类、`fp_id` 一致、`describe()` 完整。
- 结构测试：62 个文件与目录存在、19 个阶段组件可实例化、CLI 子进程退出码 0。
- 流水线测试：阶段覆盖 FP-01 ~ FP-16、`run()` 明确未实现、报告 JSON 可写出。
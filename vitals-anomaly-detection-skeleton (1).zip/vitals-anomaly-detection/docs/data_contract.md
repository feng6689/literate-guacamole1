# 数据契约

## 规模与分布

| 项目 | 取值 |
| --- | --- |
| 记录数 | 68,000 条 |
| 时间粒度 | 10 分钟聚合快照 |
| 机构数 | 15 家 |
| 模型输入特征 | 22 个 |
| 标签正例率 | 约 1.8% |
| 传感器伪影比例 | 约 3% |
| 标签噪声比例 | 约 2% |

## 标签与元数据

| 列名 | 类型 | 说明 |
| --- | --- | --- |
| `vitals_anomaly_flag` | 二值 | 1 = 真实恶化事件，0 = 正常 |
| `patient_id` | 字符串 | 患者标识，切分与分组的最小单位 |
| `facility_id` | 类别 | 机构标识；**不进入模型**，仅用于切分、校准与公平性审计 |
| `snapshot_start_ts` | 时间戳 | 快照起始时间，用于时间切分与泄漏检查 |
| `sex` | 类别 | 公平性审计分组字段 |

## 22 个输入特征

| 特征 | 类型 | 单位 | 取值范围 | 备注 |
| --- | --- | --- | --- | --- |
| `heart_rate_avg` | 数值 | bpm | 40–180 | 窗口平均心率 |
| `heart_rate_variability` | 数值 | ms | 0.3–150 | 逐搏间期标准差 |
| `systolic_bp` | 数值 | mmHg | 65–235 | 平均收缩压 |
| `diastolic_bp` | 数值 | mmHg | 30–150 | 平均舒张压 |
| `respiratory_rate` | 数值 | 次/分 | 4–50 | 窗口平均呼吸频率 |
| `oxygen_saturation` | 数值 | % | 60–100 | SpO2 |
| `body_temperature` | 数值 | °C | 33.0–42.0 | 核心体温 |
| `pulse_pressure` | 数值 | mmHg | 10–140 | 收缩压减舒张压 |
| `consciousness_score` | 有序 | 分 | 0–3 | 0 无反应、1 对声音、2 对疼痛、3 清醒 |
| `age` | 数值 | 岁 | 18–99 | 患者年龄 |
| `weight_kg` | 数值 | kg | 30–200 | 体重 |
| `infusion_rate_ml_h` | 数值 | mL/h | 0–600 | 当前输液速率 |
| `elapsed_hours_since_admission` | 数值 | 小时 | 0.5–960 | 入院至今 |
| `bed_movement_index` | 数值 | 指数 | 0–12 | 床垫压力传感器活动指数 |
| `device_model_code` | 类别 | 编码 | — | 设备型号；需检测机构代理性 |
| `acquisition_period_code` | 类别 | 编码 | — | 采集时段；需检测班次代理性 |
| `prior_24h_alarm_count` | 数值 | 次 | ≥0 | 既往 24 小时报警次数 |
| `prior_24h_intervention_count` | 数值 | 次 | ≥0 | 既往 24 小时干预次数 |
| `comorbidity_count` | 数值 | 个 | ≥0 | 合并症数量 |
| `active_medication_classes` | 数值 | 类 | ≥0 | 当前用药类别数 |
| `nurse_shift_code` | 类别 | 编码 | — | 护士班次；需检测代理泄漏 |
| `sensor_quality_score` | 数值 | 比例 | 0–1 | 信号质量评分 |

`vitals_delta_rate` 为派生特征：按 `patient_id` 与 `snapshot_start_ts` 排序后，取相邻快照生命体征变化率，仅允许使用当前及过去窗口；不计入上述 22 个原始特征。

## 切分与泄漏控制

- 训练/验证/测试按患者隔离，同一患者不得跨集合；时间上训练集必须早于验证集与测试集。
- 禁止使用相对于预测时点属于未来窗口的派生特征。
- FP-11 的目标编码必须采用 5 折折外方案，任何一折的编码不得使用该折标签。
- `facility_id`、`nurse_shift_code`、`device_model_code`、`acquisition_period_code` 需做代理泄漏检测，必要时剔除。
- 冻结策略：验证集与测试集只做 `transform`，不得重新拟合任何统计量。

## 校验入口

```python
from vitals_anomaly.data.schema import SchemaValidator
report = SchemaValidator().validate(frame)   # 列、类型、范围、标签、缺失
SchemaValidator().assert_contract(frame)     # 阻断级问题抛 SchemaError
```

`SchemaValidator` 只做契约检查，不修改数据，也不接触训练逻辑。合成数据脚本 `scripts/generate_synthetic_data.py` 的生成逻辑仍为占位实现。
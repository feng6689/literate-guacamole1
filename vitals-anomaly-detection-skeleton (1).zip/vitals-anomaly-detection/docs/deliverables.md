# 交付物清单（FP-01 ~ FP-16）

所有组件继承 `DeliverableComponent`，声明 `fp_id` 并实现 `describe()`；入口方法当前均为占位实现。模块路径省略前缀 `vitals_anomaly.`。

| FP | 交付物 | 模块 / 类 / 入口 | 验收要点 |
| --- | --- | --- | --- |
| FP-01 | 隐式反馈交互矩阵 | `features.interaction_matrix` / `InteractionMatrixBuilder.build` | 行=患者、列=离散事件类型、值=频次，叠加时间衰减 |
| FP-02 | NumPy 矩阵生成与校验 | `features.interaction_matrix` / `NumpyMatrixGenerator.generate` | 维度、稀疏性、无 NaN/Inf、非负 |
| FP-03 | 单变量 F 检验筛选 | `features.selectors` / `UnivariateFSelector.fit` | p<0.01 保留并排名，附噪声稳定性 |
| FP-04 | Bagging 集成 | `models.bagging` / `BaggingEnsemble.fit` | ≥200 棵树，max_samples=0.75，max_features=0.6，报告 OOB |
| FP-05 | 软投票集成 | `models.voting` / `SoftVotingEnsemble.fit` | ≥3 个异构成员，权重搜索最大化命中率，代价敏感 |
| FP-06 | Hit Rate@K | `evaluation.metrics` / `HitRateEvaluator.hit_rate_at_k` | K=5/10/20/50，自助 95% CI，分层报告 |
| FP-07 | Pickle 打包与往返校验 | `models.persistence` / `ArtifactBundle.save` | 加载前后预测一致，缺失工件可降级 |
| FP-08 | 分布画像 | `features.profiling` / `DistributionProfiler.profile_numeric` | 40 箱直方图、箱线图、IQR 边界、机构分组 |
| FP-09 | 多项式扩展与剪枝 | `features.polynomial` / `PolynomialExpander.expand` | 前 8 特征 degree=2，剪枝后仅保留增益项 |
| FP-10 | SHAP 解释 | `explain.shap_explainer` / `ShapExplainer.global_importance` | 全局条形图、蜂群图、局部解释与稳定性 |
| FP-11 | 折外目标编码 | `features.target_encoding` / `OOFWeightEncoder.fit_transform` | 5 折折外，逐折自证无泄漏，检测代理泄漏 |
| FP-12 | 学习曲线 | `evaluation.learning_curve` / `LearningCurveAnalyzer.compute` | 10%~100% 共 10 档，诊断偏差-方差并判断收敛 |
| FP-13 | 跨机构泛化 | `evaluation.cross_facility` / `CrossFacilityGeneralizer.leave_one_facility_out` | 逐机构 AP 衰减、校准与重加权 |
| FP-14 | 噪声鲁棒性实验 | `evaluation.noise_robustness` / `NoiseRobustnessExperiment.run` | 2% 标签噪声下对比三种损失并给推荐 |
| FP-15 | 公平性审计 | `evaluation.fairness` / `FairnessAuditor.group_metrics` | 机构/年龄/性别差异判定与缓解建议 |
| FP-16 | 在线评分与漂移监测 | `serving.service` / `OnlineScoringService.serve` | 500 条/批、300ms 预算、PSI 超阈值降级 |

## 流水线阶段映射

19 个阶段按 `pipeline/stages.py` 顺序执行：

```text
schema → split → preprocess → interaction_matrix → matrix_generation →
feature_selection → bagging → soft_voting → hit_rate → bundle →
distribution → polynomial → shap → oof_encoding → learning_curve →
cross_facility → noise_robustness → fairness → online_serving
```

FP-01 ~ FP-16 全部被覆盖；`covered_fp_ids()` 与测试会校验覆盖关系，缺失任何一项都会失败。

## 状态说明

- 结构、注册、参数契约与验收要点已完成。
- 算法逻辑、指标计算、图件生成与模型训练均未实现，调用时抛 `ComponentNotImplementedError`。
- FP-16 的 `check_latency_budget` 是唯一已实现的辅助方法，用于按 P95 判断是否满足 300ms 预算；它不涉及模型推理。

## 依赖审计

- FP-01/02/03/08/09/11：仅需 numpy/pandas；FP-10 需 shap；FP-04/05/09/12/14 需 scikit-learn；FP-08/10 绘图需 matplotlib。
- 这些库当前未安装，因此实现时必须在方法内延迟导入，不得放入模块顶层或 `requirements.txt`，直到完成依赖升级登记。
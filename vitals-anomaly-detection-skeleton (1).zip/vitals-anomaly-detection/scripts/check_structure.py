#!/usr/bin/env python3
"""结构自检脚本：文件清单、特征契约与 FP-01 ~ FP-16 挂载情况。"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from vitals_anomaly.cli import build_structure_report  # noqa: E402


def main() -> int:
    """打印 JSON 报告，全部通过返回 0，否则返回 1。"""
    report = build_structure_report()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
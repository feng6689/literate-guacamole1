#!/usr/bin/env python3
"""生成合成监护记录。

骨架阶段只保留参数契约与数据契约说明，实际生成逻辑待实现。
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from vitals_anomaly.constants import N_RECORDS, POSITIVE_RATE  # noqa: E402
from vitals_anomaly.core import ComponentNotImplementedError  # noqa: E402
from vitals_anomaly.logging_utils import configure_logging, get_logger  # noqa: E402


def generate(rows: int, anomaly_rate: float, seed: int) -> None:
    """按契约生成 22 个特征、标签与元数据列。"""
    raise ComponentNotImplementedError(
        "TODO(data): 生成 68,000 条 10 分钟快照，注入 3% 传感器伪影与 2% 标签噪声；"
        "保证 facility_id、patient_id、snapshot_start_ts 可复现"
    )


def main(argv: list[str] | None = None) -> int:
    """解析参数并调用生成器。"""
    parser = argparse.ArgumentParser(description="生成合成患者监护记录")
    parser.add_argument("--rows", type=int, default=N_RECORDS)
    parser.add_argument("--anomaly-rate", type=float, default=POSITIVE_RATE)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--output", type=Path, default=Path("data/raw/vitals_snapshots.csv")
    )
    args = parser.parse_args(argv)
    configure_logging()
    logger = get_logger("synth")
    if args.rows <= 0:
        logger.error("--rows 必须大于 0")
        return 2
    if not 0 < args.anomaly_rate < 1:
        logger.error("--anomaly-rate 必须位于 (0, 1)")
        return 2
    try:
        generate(args.rows, args.anomaly_rate, args.seed)
    except NotImplementedError as exc:
        logger.error("骨架尚未实现：%s", exc)
        return 2
    logger.info("已写入 %s", args.output)
    return 0


if __name__ == "__main__":
    sys.exit(main())
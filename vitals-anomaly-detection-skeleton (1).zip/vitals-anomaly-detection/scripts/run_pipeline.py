#!/usr/bin/env python3
"""流水线快捷入口：把配置路径转交给统一 CLI。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from vitals_anomaly.cli import main as cli_main  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    """解析命令与配置后调用 CLI。"""
    parser = argparse.ArgumentParser(description="运行生命体征异常检测流水线")
    parser.add_argument("command", choices=("train", "evaluate", "audit", "serve"))
    parser.add_argument("--config", type=Path, default=Path("configs/base.json"))
    args = parser.parse_args(argv)
    return cli_main([args.command, "--config", str(args.config)])


if __name__ == "__main__":
    sys.exit(main())
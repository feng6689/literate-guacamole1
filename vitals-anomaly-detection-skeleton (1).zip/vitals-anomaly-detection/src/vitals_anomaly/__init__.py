"""床旁生命体征异常检测系统。

本包为项目骨架：数据契约、配置、流水线编排与 FP-01 ~ FP-16 交付物组件均已
就位，算法实现以待办形式保留，便于逐项填充。
"""

from __future__ import annotations

__version__ = "0.1.0"
PROJECT_NAME = "vitals-anomaly-detection"

__all__ = ["__version__", "PROJECT_NAME"]
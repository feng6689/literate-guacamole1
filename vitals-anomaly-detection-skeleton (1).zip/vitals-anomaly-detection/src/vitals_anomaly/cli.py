"""命令行入口。"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

from .config import PipelineConfig
from .constants import validate_feature_contract
from .core import ProjectError
from .logging_utils import configure_logging, get_logger
from .manifest import check_manifest
from .pipeline.runner import ProjectPipeline
from .registry import check_registry

LOGGER = get_logger("cli")

COMMANDS = ("check-structure", "train", "evaluate", "audit", "serve")


def build_structure_report() -> Dict[str, Any]:
    """汇总文件清单、特征契约与交付物注册表三项自检。"""
    manifest = check_manifest()
    registry = check_registry()
    contract = validate_feature_contract()
    return {
        "project": "vitals-anomaly-detection",
        "ok": manifest.ok and registry["ok"] and bool(contract["ok"]),
        "manifest": manifest.to_dict(),
        "feature_contract": contract,
        "registry": registry,
    }


def build_parser() -> argparse.ArgumentParser:
    """构造 CLI 解析器。"""
    parser = argparse.ArgumentParser(
        prog="vitals-anomaly",
        description="床旁生命体征异常检测系统骨架（结构完整、算法待实现）",
    )
    parser.add_argument("--config", type=Path, default=None, help="JSON 配置路径")
    _add_log_level(parser, default="INFO")
    subparsers = parser.add_subparsers(dest="command", required=True)
    helps = {
        "check-structure": "自检文件清单、特征契约与交付物挂载",
        "train": "执行训练流水线（待实现）",
        "evaluate": "执行评估与分层报告（待实现）",
        "audit": "执行跨机构与公平性审计（待实现）",
        "serve": "启动在线评分与漂移监测（待实现）",
    }
    for name, help_text in helps.items():
        subparser = subparsers.add_parser(name, help=help_text)
        # 允许 --config/--log-level 写在子命令之后；SUPPRESS 避免覆盖全局取值
        subparser.add_argument(
            "--config", type=Path, default=argparse.SUPPRESS,
            help="JSON 配置路径（可写在子命令后）",
        )
        _add_log_level(subparser, default=argparse.SUPPRESS, help_text=argparse.SUPPRESS)
    return parser


def _add_log_level(
    parser: argparse.ArgumentParser,
    default: Any = "INFO",
    help_text: Any = None,
) -> None:
    """注册日志级别参数，子命令副本使用 SUPPRESS 以避免覆盖全局值。"""
    parser.add_argument(
        "--log-level",
        default=default,
        choices=("DEBUG", "INFO", "WARNING", "ERROR"),
        help=help_text,
    )


def main(argv: Optional[Sequence[str]] = None) -> int:
    """命令行调度，返回进程退出码。"""
    args = build_parser().parse_args(argv)
    configure_logging(getattr(__import__("logging"), args.log_level))

    if args.command == "check-structure":
        report = build_structure_report()
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report["ok"] else 1

    config = PipelineConfig.from_json(args.config) if args.config else PipelineConfig()
    issues = config.validate()
    if issues:
        for issue in issues:
            LOGGER.error("配置错误：%s", issue)
        return 2

    try:
        ProjectPipeline(config).run()
    except NotImplementedError as exc:
        LOGGER.error("骨架尚未实现：%s", exc)
        LOGGER.error("请按异常中的 FP 编号逐项补充实现后重试")
        return 2
    except ProjectError as exc:
        LOGGER.error("流水线执行失败：%s", exc)
        return 3
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
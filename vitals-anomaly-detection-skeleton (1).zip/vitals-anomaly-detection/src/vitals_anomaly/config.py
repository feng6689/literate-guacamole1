"""配置对象与 JSON 读写。

配置分节与 ``configs/*.json`` 一一对应；``from_json`` 会做类型归一化
（路径、元组）与基本合法性校验。
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, get_origin, get_type_hints

from .constants import (
    AP_TARGET,
    BATCH_SIZE,
    BOOTSTRAP_ROUNDS,
    CONFIDENCE_LEVEL,
    DRIFT_PSI_THRESHOLD,
    DRIFT_WINDOW,
    FAIRNESS_GAP_THRESHOLD,
    FAIRNESS_GROUPS,
    FAIRNESS_METRICS,
    FAIRNESS_MIN_GROUP_SIZE,
    GROUP_COLUMN,
    HIT_RATE_KS,
    HIT_RATE_TARGET,
    LABEL_NOISE_RATE,
    LATENCY_BUDGET_MS,
    RANDOM_STATE,
    RETRAIN_ALERT_COOLDOWN_MINUTES,
    TIME_COLUMN,
)


@dataclass
class DataConfig:
    """数据路径与划分策略。"""

    raw_path: Path = Path("data/raw/vitals_snapshots.csv")
    processed_dir: Path = Path("data/processed")
    artifact_dir: Path = Path("artifacts")
    report_dir: Path = Path("reports")
    test_size: float = 0.20
    validation_size: float = 0.20
    group_column: str = GROUP_COLUMN
    time_column: str = TIME_COLUMN
    enforce_time_order: bool = True
    drop_leakage_features: bool = False


@dataclass
class PreprocessConfig:
    """缺失值、缩放、编码与派生特征策略。"""

    numeric_imputer: str = "median"
    categorical_imputer: str = "most_frequent"
    scaler: str = "standard"
    ordinal_mapping: Mapping[str, Sequence[int]] = field(
        default_factory=lambda: {"consciousness_score": (0, 1, 2, 3)}
    )
    clip_outliers: bool = True
    compute_delta_rate: bool = True
    delta_rate_lag: int = 1


@dataclass
class BaggingConfig:
    """FP-04 Bagging 集成参数。"""

    n_estimators: int = 200
    max_samples: float = 0.75
    max_features: float = 0.60
    bootstrap: bool = True
    oob_score: bool = True
    base_estimator: str = "decision_tree"
    random_state: int = RANDOM_STATE


@dataclass
class VotingConfig:
    """FP-05 软投票集成参数。"""

    members: Tuple[str, ...] = (
        "bagging", "gradient_boosting", "logistic_regression", "mlp",
    )
    weight_grid_step: float = 0.05
    optimize_metric: str = "hit_rate"
    cost_sensitive: bool = True
    positive_class_cost: float = 10.0
    calibration: str = "sigmoid"


@dataclass
class RobustnessConfig:
    """FP-14 标签噪声鲁棒性实验参数。"""

    label_noise_rate: float = LABEL_NOISE_RATE
    losses: Tuple[str, ...] = ("cross_entropy", "cost_sensitive", "noise_robust")
    noise_robust_loss: str = "symmetric_cross_entropy"
    repetitions: int = 5


@dataclass
class EvalConfig:
    """评估与报告参数。"""

    primary_metric: str = "average_precision"
    ap_target: float = AP_TARGET
    hit_rate_target: float = HIT_RATE_TARGET
    hit_rate_ks: Tuple[int, ...] = HIT_RATE_KS
    bootstrap_rounds: int = BOOTSTRAP_ROUNDS
    confidence_level: float = CONFIDENCE_LEVEL
    stratified_subsets: Tuple[str, ...] = ("artifact", "label_noise", "facility")


@dataclass
class FairnessConfig:
    """FP-15 公平性审计参数。"""

    groups: Tuple[str, ...] = FAIRNESS_GROUPS
    gap_threshold: float = FAIRNESS_GAP_THRESHOLD
    min_group_size: int = FAIRNESS_MIN_GROUP_SIZE
    metrics: Tuple[str, ...] = FAIRNESS_METRICS


@dataclass
class ServingConfig:
    """FP-16 在线推理与漂移监测参数。"""

    batch_size: int = BATCH_SIZE
    latency_budget_ms: float = LATENCY_BUDGET_MS
    drift_psi_threshold: float = DRIFT_PSI_THRESHOLD
    drift_window: int = DRIFT_WINDOW
    retrain_alert_cooldown_minutes: int = RETRAIN_ALERT_COOLDOWN_MINUTES
    degrade_on_drift: bool = True


@dataclass
class PipelineConfig:
    """全流程配置聚合。"""

    data: DataConfig = field(default_factory=DataConfig)
    preprocess: PreprocessConfig = field(default_factory=PreprocessConfig)
    bagging: BaggingConfig = field(default_factory=BaggingConfig)
    voting: VotingConfig = field(default_factory=VotingConfig)
    robustness: RobustnessConfig = field(default_factory=RobustnessConfig)
    evaluation: EvalConfig = field(default_factory=EvalConfig)
    fairness: FairnessConfig = field(default_factory=FairnessConfig)
    serving: ServingConfig = field(default_factory=ServingConfig)

    # -- 构造 ---------------------------------------------------------
    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "PipelineConfig":
        """从字典构造；未知字段忽略，缺失字段用默认值。"""
        hints = get_type_hints(cls)
        kwargs: Dict[str, Any] = {}
        for f in fields(cls):
            if f.name not in payload:
                continue
            section_type = hints[f.name]
            section_payload = payload[f.name] or {}
            if not isinstance(section_payload, Mapping):
                raise ValueError(f"配置节 {f.name} 必须是对象")
            kwargs[f.name] = _build_dataclass(section_type, section_payload)
        return cls(**kwargs)

    @classmethod
    def from_json(cls, path: Path) -> "PipelineConfig":
        """从 JSON 文件加载配置。"""
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("配置文件根节点必须是对象")
        return cls.from_dict(payload)

    # -- 导出 ---------------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        """导出为便于 JSON 序列化的字典。"""
        return {key: _jsonable(value) for key, value in asdict(self).items()}

    def to_json(self, path: Path) -> Path:
        """写入 JSON 文件并返回路径。"""
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(self.to_dict(), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return target

    # -- 校验 ---------------------------------------------------------
    def validate(self) -> List[str]:
        """返回配置问题清单，空列表表示通过。"""
        issues: List[str] = []
        if not 0 < self.data.test_size < 1:
            issues.append("data.test_size 必须位于 (0, 1)")
        if not 0 <= self.data.validation_size < 1:
            issues.append("data.validation_size 必须位于 [0, 1)")
        if self.data.test_size + self.data.validation_size >= 1:
            issues.append("训练集比例必须大于 0：test_size + validation_size 应小于 1")
        if not 0 < self.evaluation.ap_target <= 1:
            issues.append("evaluation.ap_target 必须位于 (0, 1]")
        if not 0 < self.evaluation.hit_rate_target <= 1:
            issues.append("evaluation.hit_rate_target 必须位于 (0, 1]")
        if not self.evaluation.hit_rate_ks or min(self.evaluation.hit_rate_ks) <= 0:
            issues.append("evaluation.hit_rate_ks 必须为正整数序列")
        if self.bagging.n_estimators < 1:
            issues.append("bagging.n_estimators 至少为 1")
        if not 0 < self.bagging.max_samples <= 1:
            issues.append("bagging.max_samples 必须位于 (0, 1]")
        if not 0 < self.bagging.max_features <= 1:
            issues.append("bagging.max_features 必须位于 (0, 1]")
        if self.voting.positive_class_cost <= 0:
            issues.append("voting.positive_class_cost 必须大于 0")
        if self.serving.batch_size <= 0:
            issues.append("serving.batch_size 必须大于 0")
        if self.serving.latency_budget_ms <= 0:
            issues.append("serving.latency_budget_ms 必须大于 0")
        if self.fairness.gap_threshold < 0:
            issues.append("fairness.gap_threshold 不能为负")
        return issues


def _build_dataclass(cls: Any, payload: Mapping[str, Any]) -> Any:
    """按字段类型构造子配置，处理 Path 与 Tuple 的归一化。"""
    hints = get_type_hints(cls)
    kwargs: Dict[str, Any] = {}
    for f in fields(cls):
        if f.name not in payload:
            continue
        kwargs[f.name] = _coerce(payload[f.name], hints.get(f.name))
    return cls(**kwargs)


def _coerce(value: Any, hint: Any) -> Any:
    """把 JSON 原生类型转换为注解声明的类型。"""
    if hint is Path:
        return Path(value)
    origin = get_origin(hint)
    if origin in (tuple, Tuple) and isinstance(value, (list, tuple)):
        return tuple(value)
    return value


def _jsonable(value: Any) -> Any:
    """递归转换为 JSON 可序列化结构。"""
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value


__all__ = [
    "DataConfig", "PreprocessConfig", "BaggingConfig", "VotingConfig",
    "RobustnessConfig", "EvalConfig", "FairnessConfig", "ServingConfig",
    "PipelineConfig",
]
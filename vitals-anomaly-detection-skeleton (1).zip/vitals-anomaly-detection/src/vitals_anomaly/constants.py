"""项目契约常量与特征规格。

所有模块共享本文件中的取值，禁止在别处硬编码重复常量。
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Tuple

PROJECT_NAME = "vitals-anomaly-detection"
PROJECT_VERSION = "0.1.0-skeleton"

# ---- 数据规模与标签分布 ------------------------------------------------
TARGET_COLUMN = "vitals_anomaly_flag"
PATIENT_COLUMN = "patient_id"
GROUP_COLUMN = "facility_id"
TIME_COLUMN = "snapshot_start_ts"
SEX_COLUMN = "sex"
WINDOW_MINUTES = 10
N_RECORDS = 68_000
N_FACILITIES = 15
N_INPUT_FEATURES = 22
POSITIVE_RATE = 0.018
ARTIFACT_RATE = 0.03
LABEL_NOISE_RATE = 0.02

# ---- 业务基线（升级前规则系统） ----------------------------------------
LEGACY_FALSE_POSITIVE_RATE = 0.86
LEGACY_ADVERSE_EVENT_INCREASE = 0.12
LEGACY_LIABILITY_COST_USD = 4_200_000

# ---- 模型目标 ----------------------------------------------------------
AP_TARGET = 0.78
HIT_RATE_TARGET = 0.92
FALSE_ALARM_REDUCTION_TARGET = 0.65
HIT_RATE_KS: Tuple[int, ...] = (5, 10, 20, 50)
BOOTSTRAP_ROUNDS = 1_000
CONFIDENCE_LEVEL = 0.95

# ---- 在线服务 ----------------------------------------------------------
BATCH_SIZE = 500
LATENCY_BUDGET_MS = 300.0
DRIFT_PSI_THRESHOLD = 0.20
DRIFT_WINDOW = 2_000
RETRAIN_ALERT_COOLDOWN_MINUTES = 60

# ---- 公平性 ------------------------------------------------------------
FAIRNESS_GAP_THRESHOLD = 0.05
FAIRNESS_GROUPS: Tuple[str, ...] = ("facility_id", "age_band", "sex")
FAIRNESS_MIN_GROUP_SIZE = 200
FAIRNESS_METRICS: Tuple[str, ...] = ("hit_rate", "false_positive_rate")

RANDOM_STATE = 42


class FeatureKind(str, Enum):
    """特征类型，决定预处理方式与泄漏检查策略。"""

    NUMERIC = "numeric"
    ORDINAL = "ordinal"
    CATEGORICAL = "categorical"


@dataclass(frozen=True)
class FeatureSpec:
    """单个模型输入特征的契约。"""

    name: str
    kind: FeatureKind
    unit: str
    minimum: Optional[float]
    maximum: Optional[float]
    description: str
    leakage_risk: str = "none"


# 22 个模型输入特征；facility_id 仅作分组元数据，不进入模型。
FEATURE_SPECS: Tuple[FeatureSpec, ...] = (
    FeatureSpec("heart_rate_avg", FeatureKind.NUMERIC, "bpm", 40.0, 180.0,
                "10 分钟窗口内平均心率"),
    FeatureSpec("heart_rate_variability", FeatureKind.NUMERIC, "ms", 0.3, 150.0,
                "逐搏间期标准差形式的心率变异性"),
    FeatureSpec("systolic_bp", FeatureKind.NUMERIC, "mmHg", 65.0, 235.0, "平均收缩压"),
    FeatureSpec("diastolic_bp", FeatureKind.NUMERIC, "mmHg", 30.0, 150.0, "平均舒张压"),
    FeatureSpec("respiratory_rate", FeatureKind.NUMERIC, "breaths/min", 4.0, 50.0,
                "窗口内平均呼吸频率"),
    FeatureSpec("oxygen_saturation", FeatureKind.NUMERIC, "%", 60.0, 100.0,
                "外周血氧饱和度 SpO2"),
    FeatureSpec("body_temperature", FeatureKind.NUMERIC, "Celsius", 33.0, 42.0, "核心体温"),
    FeatureSpec("pulse_pressure", FeatureKind.NUMERIC, "mmHg", 10.0, 140.0,
                "心血管搏动性派生指标（收缩压减舒张压）"),
    FeatureSpec("consciousness_score", FeatureKind.ORDINAL, "score", 0.0, 3.0,
                "警觉性量表：0 无反应、1 对声音有反应、2 对疼痛有反应、3 清醒"),
    FeatureSpec("age", FeatureKind.NUMERIC, "years", 18.0, 99.0, "患者年龄"),
    FeatureSpec("weight_kg", FeatureKind.NUMERIC, "kg", 30.0, 200.0, "患者体重"),
    FeatureSpec("infusion_rate_ml_h", FeatureKind.NUMERIC, "mL/h", 0.0, 600.0,
                "当前静脉输液速率"),
    FeatureSpec("elapsed_hours_since_admission", FeatureKind.NUMERIC, "hours", 0.5, 960.0,
                "入院至今经过小时数"),
    FeatureSpec("bed_movement_index", FeatureKind.NUMERIC, "index", 0.0, 12.0,
                "床垫压力传感器得出的活动指数"),
    FeatureSpec("device_model_code", FeatureKind.CATEGORICAL, "code", None, None,
                "监护设备型号编码",
                leakage_risk="设备型号与机构、科室相关，可能构成机构代理变量"),
    FeatureSpec("acquisition_period_code", FeatureKind.CATEGORICAL, "code", None, None,
                "采集时段编码",
                leakage_risk="时段与护理强度相关，可能构成班次代理变量"),
    FeatureSpec("prior_24h_alarm_count", FeatureKind.NUMERIC, "count", 0.0, None,
                "既往 24 小时报警次数"),
    FeatureSpec("prior_24h_intervention_count", FeatureKind.NUMERIC, "count", 0.0, None,
                "既往 24 小时临床干预次数"),
    FeatureSpec("comorbidity_count", FeatureKind.NUMERIC, "count", 0.0, None,
                "合并症数量"),
    FeatureSpec("active_medication_classes", FeatureKind.NUMERIC, "count", 0.0, None,
                "当前用药类别数"),
    FeatureSpec("nurse_shift_code", FeatureKind.CATEGORICAL, "code", None, None,
                "护士班次编码",
                leakage_risk="班次与记录质量、报警处置速度相关，需检测代理泄漏"),
    FeatureSpec("sensor_quality_score", FeatureKind.NUMERIC, "ratio", 0.0, 1.0,
                "传感器信号质量评分"),
)

FEATURE_NAMES: Tuple[str, ...] = tuple(spec.name for spec in FEATURE_SPECS)
FEATURE_BY_NAME: Dict[str, FeatureSpec] = {spec.name: spec for spec in FEATURE_SPECS}
NUMERIC_FEATURES: Tuple[str, ...] = tuple(
    spec.name for spec in FEATURE_SPECS if spec.kind is FeatureKind.NUMERIC
)
ORDINAL_FEATURES: Tuple[str, ...] = tuple(
    spec.name for spec in FEATURE_SPECS if spec.kind is FeatureKind.ORDINAL
)
CATEGORICAL_FEATURES: Tuple[str, ...] = tuple(
    spec.name for spec in FEATURE_SPECS if spec.kind is FeatureKind.CATEGORICAL
)
DERIVED_FEATURES: Tuple[str, ...] = ("vitals_delta_rate",)
LEAKAGE_SENSITIVE_FEATURES: Tuple[str, ...] = tuple(
    spec.name for spec in FEATURE_SPECS if spec.leakage_risk != "none"
)
METADATA_COLUMNS: Tuple[str, ...] = (PATIENT_COLUMN, GROUP_COLUMN, TIME_COLUMN)
MONITORED_DRIFT_FEATURES: Tuple[str, ...] = NUMERIC_FEATURES + DERIVED_FEATURES
REQUIRED_COLUMNS: Tuple[str, ...] = FEATURE_NAMES + METADATA_COLUMNS + (TARGET_COLUMN,)


def validate_feature_contract() -> Dict[str, object]:
    """校验 22 个特征契约本身是否自洽，返回可机读报告。"""
    issues: List[str] = []
    names = [spec.name for spec in FEATURE_SPECS]
    duplicates = sorted({name for name in names if names.count(name) > 1})

    if len(FEATURE_SPECS) != N_INPUT_FEATURES:
        issues.append(f"特征数量为 {len(FEATURE_SPECS)}，契约要求 {N_INPUT_FEATURES}")
    if duplicates:
        issues.append(f"特征名重复：{duplicates}")
    if TARGET_COLUMN in names:
        issues.append("标签列不得出现在特征列表中")
    if GROUP_COLUMN in names:
        issues.append("facility_id 必须作为分组元数据，不得进入模型特征")

    for spec in FEATURE_SPECS:
        if spec.kind is FeatureKind.CATEGORICAL:
            if spec.minimum is not None or spec.maximum is not None:
                issues.append(f"{spec.name} 为类别特征，不应声明数值范围")
            continue
        if spec.minimum is None and spec.maximum is None:
            issues.append(f"{spec.name} 缺少任何取值边界")
        elif spec.minimum is not None and spec.maximum is not None and spec.minimum > spec.maximum:
            issues.append(f"{spec.name} 最小值大于最大值")

    return {
        "ok": not issues,
        "n_features": len(FEATURE_SPECS),
        "issues": issues,
        "numeric": len(NUMERIC_FEATURES),
        "ordinal": len(ORDINAL_FEATURES),
        "categorical": len(CATEGORICAL_FEATURES),
        "leakage_sensitive": list(LEAKAGE_SENSITIVE_FEATURES),
    }


__all__ = [
    "PROJECT_NAME", "PROJECT_VERSION", "TARGET_COLUMN", "PATIENT_COLUMN",
    "GROUP_COLUMN", "TIME_COLUMN", "SEX_COLUMN", "WINDOW_MINUTES", "N_RECORDS",
    "N_FACILITIES", "N_INPUT_FEATURES", "POSITIVE_RATE", "ARTIFACT_RATE",
    "LABEL_NOISE_RATE", "LEGACY_FALSE_POSITIVE_RATE", "LEGACY_ADVERSE_EVENT_INCREASE",
    "LEGACY_LIABILITY_COST_USD", "AP_TARGET", "HIT_RATE_TARGET",
    "FALSE_ALARM_REDUCTION_TARGET", "HIT_RATE_KS", "BOOTSTRAP_ROUNDS",
    "CONFIDENCE_LEVEL", "BATCH_SIZE", "LATENCY_BUDGET_MS", "DRIFT_PSI_THRESHOLD",
    "DRIFT_WINDOW", "RETRAIN_ALERT_COOLDOWN_MINUTES", "FAIRNESS_GAP_THRESHOLD",
    "FAIRNESS_GROUPS", "FAIRNESS_MIN_GROUP_SIZE", "FAIRNESS_METRICS", "RANDOM_STATE",
    "FeatureKind", "FeatureSpec", "FEATURE_SPECS", "FEATURE_NAMES", "FEATURE_BY_NAME",
    "NUMERIC_FEATURES", "ORDINAL_FEATURES", "CATEGORICAL_FEATURES", "DERIVED_FEATURES",
    "LEAKAGE_SENSITIVE_FEATURES", "METADATA_COLUMNS", "MONITORED_DRIFT_FEATURES",
    "REQUIRED_COLUMNS", "validate_feature_contract",
]
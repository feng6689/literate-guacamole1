"""运行上下文：数据包与流水线状态载体。"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

from .constants import FEATURE_NAMES

if TYPE_CHECKING:  # pragma: no cover
    from .config import PipelineConfig


@dataclass
class DataBundle:
    """一次运行中在内存里流转的数据对象。"""

    train: Any
    validation: Any
    test: Any
    feature_names: Tuple[str, ...] = FEATURE_NAMES
    metadata: Dict[str, Any] = field(default_factory=dict)

    def sizes(self) -> Dict[str, Optional[int]]:
        """返回各集合样本量，兼容 DataFrame 与 ndarray。"""
        def _len(obj: Any) -> Optional[int]:
            try:
                return len(obj)
            except TypeError:
                return None

        return {"train": _len(self.train), "validation": _len(self.validation),
                "test": _len(self.test)}


@dataclass
class PipelineContext:
    """流水线上下文：承载配置、数据、产物、指标与报告。"""

    config: "PipelineConfig"
    data: Optional[DataBundle] = None
    artifacts: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)
    reports: Dict[str, Any] = field(default_factory=dict)
    failures: Dict[str, str] = field(default_factory=dict)
    started_at: float = field(default_factory=time.time)

    def record_artifact(self, key: str, value: Any) -> None:
        """登记中间产物，空键直接拒绝。"""
        if not key:
            raise ValueError("artifact key 不能为空")
        self.artifacts[key] = value

    def elapsed_seconds(self) -> float:
        """返回自上下文创建以来的耗时。"""
        return time.time() - self.started_at

    def summary(self) -> Dict[str, Any]:
        """输出可序列化的运行摘要。"""
        return {
            "elapsed_seconds": round(self.elapsed_seconds(), 3),
            "n_artifacts": len(self.artifacts),
            "metrics": dict(self.metrics),
            "failures": dict(self.failures),
            "data_sizes": self.data.sizes() if self.data else None,
        }


__all__ = ["DataBundle", "PipelineContext"]
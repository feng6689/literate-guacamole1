"""组件基类、异常与可选依赖加载工具。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict


class ProjectError(Exception):
    """项目内所有可预期错误的基类。"""


class SchemaError(ProjectError):
    """数据契约不满足时抛出。"""


class ComponentNotImplementedError(ProjectError, NotImplementedError):
    """骨架占位实现被调用时抛出，消息中必须包含 FP 编号。"""


class RegistryError(ProjectError):
    """交付物注册表无法解析组件时抛出。"""


def lazy_import(module_name: str) -> Any:
    """延迟导入可选依赖，避免骨架在精简环境中无法加载。"""
    try:
        return __import__(module_name)
    except ImportError as exc:  # pragma: no cover - 环境相关
        raise ImportError(
            f"缺少依赖 {module_name!r}；请先在 README 的依赖升级一节登记并安装"
        ) from exc


class DeliverableComponent(ABC):
    """FP-01 ~ FP-16 交付物组件基类。

    每个子类必须声明 ``fp_id`` 并实现 ``describe``，结构自检依赖这两个契约。
    """

    fp_id: str = "FP-00"

    @abstractmethod
    def describe(self) -> Dict[str, Any]:
        """返回交付物标题、入口方法与验收要点。"""


__all__ = [
    "ProjectError", "SchemaError", "ComponentNotImplementedError", "RegistryError",
    "lazy_import", "DeliverableComponent",
]
"""数据层：契约校验与集合切分。"""

from __future__ import annotations

from .schema import SchemaValidator
from .splitter import TemporalSplitter

__all__ = ["SchemaValidator", "TemporalSplitter"]
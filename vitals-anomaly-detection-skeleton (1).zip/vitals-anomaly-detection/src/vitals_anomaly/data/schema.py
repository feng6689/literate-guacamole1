"""数据契约校验。

实现部分为真实的列、类型、取值范围与标签检查；不涉及模型训练逻辑。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from ..constants import (
    FEATURE_SPECS,
    REQUIRED_COLUMNS,
    TARGET_COLUMN,
)
from ..core import SchemaError


@dataclass
class ValidationReport:
    """数据校验结果。"""

    missing_columns: List[str]
    dtype_errors: List[str]
    range_violations: Dict[str, int]
    label_values: List[int]
    null_counts: Dict[str, int]

    @property
    def ok(self) -> bool:
        return not self.missing_columns and not self.dtype_errors and not self.range_violations

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "missing_columns": self.missing_columns,
            "dtype_errors": self.dtype_errors,
            "range_violations": self.range_violations,
            "label_values": self.label_values,
            "null_counts": self.null_counts,
        }


class SchemaValidator:
    """校验 22 个特征、标签与元数据列是否符合契约。"""

    def validate(self, frame: Any) -> Dict[str, Any]:
        """返回可机读报告；不抛异常，便于批量探查。"""
        columns = list(getattr(frame, "columns", []))
        missing = [name for name in REQUIRED_COLUMNS if name not in columns]
        if missing:
            return ValidationReport(
                missing_columns=missing,
                dtype_errors=[],
                range_violations={},
                label_values=[],
                null_counts={},
            ).to_dict()

        dtype_errors: List[str] = []
        range_violations: Dict[str, int] = {}
        null_counts: Dict[str, int] = {}

        for spec in FEATURE_SPECS:
            series = frame[spec.name]
            if spec.kind.value in ("numeric", "ordinal"):
                if not _is_numeric(series):
                    dtype_errors.append(f"{spec.name} 应为数值型")
                    continue
                if spec.minimum is not None:
                    count = int((series < spec.minimum).fillna(False).sum())
                    if count:
                        range_violations[f"{spec.name}<min"] = count
                if spec.maximum is not None:
                    count = int((series > spec.maximum).fillna(False).sum())
                    if count:
                        range_violations[f"{spec.name}>max"] = count
            null_counts[spec.name] = int(series.isna().sum())

        labels = frame[TARGET_COLUMN]
        label_values = sorted({int(v) for v in labels.dropna().unique().tolist()})
        if not set(label_values).issubset({0, 1}):
            dtype_errors.append("标签列只能包含 0/1")

        return ValidationReport(
            missing_columns=[],
            dtype_errors=dtype_errors,
            range_violations=range_violations,
            label_values=label_values,
            null_counts=null_counts,
        ).to_dict()

    def assert_contract(self, frame: Any) -> None:
        """阻断级问题直接抛 SchemaError。"""
        report = self.validate(frame)
        blocking = report["missing_columns"] + report["dtype_errors"]
        if blocking:
            raise SchemaError("数据契约不满足：" + "; ".join(blocking))


def _is_numeric(series: Any) -> bool:
    """兼容 pandas 与 numpy 的数值类型判断。"""
    dtype = getattr(series, "dtype", None)
    if dtype is None:
        return False
    return bool(getattr(dtype, "kind", "")) and dtype.kind in "iuf"


__all__ = ["SchemaValidator", "ValidationReport"]
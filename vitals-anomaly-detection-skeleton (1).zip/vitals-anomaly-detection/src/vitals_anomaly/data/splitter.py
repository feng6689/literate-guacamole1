"""患者级、时间感知的数据集切分。"""

from __future__ import annotations

from typing import Any, Dict

from ..config import DataConfig
from ..context import DataBundle
from ..core import ComponentNotImplementedError


class TemporalSplitter:
    """按患者隔离、按时间顺序切分训练/验证/测试集。"""

    def split(self, frame: Any, config: DataConfig) -> DataBundle:
        """返回 train/validation/test，患者与时间窗均不得重叠。"""
        raise ComponentNotImplementedError(
            "TODO(data): 先按时间排序，再按患者分组做分层切分；"
            "禁止同一患者跨集合，禁止用未来数据训练"
        )

    def verify_no_overlap(self, bundle: DataBundle) -> Dict[str, Any]:
        """校验三个集合在患者、机构、时间上的重叠情况。"""
        raise ComponentNotImplementedError(
            "TODO(data): 输出患者/机构/时间重叠明细，重叠即判失败"
        )


__all__ = ["TemporalSplitter"]
"""FP-15：分组公平性审计。"""

from __future__ import annotations

from typing import Any, Dict, Mapping

from ..constants import FAIRNESS_GAP_THRESHOLD
from ..core import ComponentNotImplementedError, DeliverableComponent


class FairnessAuditor(DeliverableComponent):
    """FP-15：机构、年龄段、性别的命中率与误报率差异审计。"""

    fp_id = "FP-15"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "公平性审计",
            "methods": ["group_metrics", "threshold_check", "mitigation"],
            "acceptance": "分组差异判定明确基准组，超限清单与缓解建议齐全",
        }

    def group_metrics(self, scores: Any, labels: Any, groups: Mapping[str, Any]) -> Any:
        """按分组计算命中率与误报率。"""
        raise ComponentNotImplementedError(
            "TODO(FP-15): 输出每组样本量、指标与置信区间，样本不足时标注"
        )

    def threshold_check(
        self, metrics: Any, threshold: float = FAIRNESS_GAP_THRESHOLD
    ) -> Dict[str, Any]:
        """判定组间差异是否超阈值。"""
        raise ComponentNotImplementedError(
            "TODO(FP-15): 明确基准组与差值定义，输出超限项与严重程度"
        )

    def mitigation(self, metrics: Any) -> Dict[str, Any]:
        """给出阈值调整、重采样或重加权建议。"""
        raise ComponentNotImplementedError(
            "TODO(FP-15): 评估缓解措施对总体 AP 的影响，避免只优化公平性"
        )


__all__ = ["FairnessAuditor"]
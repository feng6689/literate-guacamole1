"""FP-06：Hit Rate@K、自助置信区间与分层评估。"""

from __future__ import annotations

from typing import Any, Dict, Mapping, Tuple

from ..core import ComponentNotImplementedError, DeliverableComponent


class HitRateEvaluator(DeliverableComponent):
    """FP-06：按患者会话计算 top-K 命中率。"""

    fp_id = "FP-06"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "Hit Rate@K 评估",
            "methods": ["hit_rate_at_k", "bootstrap_confidence_interval", "stratified_report"],
            "acceptance": "K=5/10/20/50，自助 95% CI，伪影与标签噪声子集分层报告",
        }

    def hit_rate_at_k(self, scores: Any, labels: Any, k: int) -> float:
        """按异常概率排序，计算前 K 个结果捕获的真实异常比例。"""
        raise ComponentNotImplementedError(
            "TODO(FP-06): 支持按患者会话分组计算 top-K，并处理并列概率"
        )

    def bootstrap_confidence_interval(
        self, scores: Any, labels: Any, k: int
    ) -> Tuple[float, float]:
        """自助重采样给出 95% 置信区间。"""
        raise ComponentNotImplementedError(
            "TODO(FP-06): 至少 1000 次重采样，按会话重抽样而非按样本"
        )

    def stratified_report(self, subsets: Mapping[str, Any]) -> Dict[str, Any]:
        """在伪影、标签噪声、机构子集上分别报告命中率。"""
        raise ComponentNotImplementedError(
            "TODO(FP-06): 输出分层表，标注样本量、置信区间与不可比说明"
        )


__all__ = ["HitRateEvaluator"]
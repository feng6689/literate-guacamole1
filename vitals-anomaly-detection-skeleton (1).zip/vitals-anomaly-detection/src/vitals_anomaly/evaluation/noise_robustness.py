"""FP-14：标签噪声鲁棒性对比实验。"""

from __future__ import annotations

from typing import Any, Dict

from ..config import RobustnessConfig
from ..core import ComponentNotImplementedError, DeliverableComponent


class NoiseRobustnessExperiment(DeliverableComponent):
    """FP-14：2% 标签噪声下的三种损失对比。"""

    fp_id = "FP-14"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "噪声鲁棒性实验",
            "methods": ["run", "compare_losses", "recommend"],
            "acceptance": "固定噪声种子重复实验，对比交叉熵、代价敏感与噪声鲁棒损失",
        }

    def run(self, features: Any, labels: Any, config: RobustnessConfig) -> Any:
        """注入标签噪声并重复训练。"""
        raise ComponentNotImplementedError(
            "TODO(FP-14): 固定噪声注入随机种子，保留每轮噪声掩码以复现"
        )

    def compare_losses(self, results: Any) -> Any:
        """对比各损失下的 AP 与命中率。"""
        raise ComponentNotImplementedError(
            "TODO(FP-14): 输出均值、标准差与配对显著性检验结果"
        )

    def recommend(self, results: Any) -> Dict[str, Any]:
        """给出推荐损失与适用条件。"""
        raise ComponentNotImplementedError(
            "TODO(FP-14): 结合训练成本与收益给出可执行建议"
        )


__all__ = ["NoiseRobustnessExperiment"]
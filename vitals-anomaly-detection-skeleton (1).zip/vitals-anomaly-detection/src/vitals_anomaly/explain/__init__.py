"""可解释性层：SHAP 解释。"""

from __future__ import annotations

from .shap_explainer import ShapExplainer

__all__ = ["ShapExplainer"]
"""FP-10：SHAP 全局与局部解释。"""

from __future__ import annotations

from typing import Any, Dict

from ..core import ComponentNotImplementedError, DeliverableComponent


class ShapExplainer(DeliverableComponent):
    """FP-10：树模型 SHAP 解释、局部示例与稳定性检验。"""

    fp_id = "FP-10"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "SHAP 解释与稳定性检验",
            "methods": ["global_importance", "beeswarm", "local_explanation", "stability_check"],
            "acceptance": "全局条形图、蜂群图、单条预测局部解释与解释稳定性",
        }

    def global_importance(self, model: Any, features: Any) -> Any:
        """生成平均 |SHAP 值| 全局重要性条形图。"""
        raise ComponentNotImplementedError(
            "TODO(FP-10): 仅解释树组件，注明不覆盖线性与神经网络成员"
        )

    def beeswarm(self, shap_values: Any, features: Any) -> Any:
        """输出蜂群图。"""
        raise ComponentNotImplementedError(
            "TODO(FP-10): 标注样本量与解释方差，避免过度解读稀有特征"
        )

    def local_explanation(self, sample: Any) -> Dict[str, Any]:
        """单条预测的局部解释与临床叙述。"""
        raise ComponentNotImplementedError(
            "TODO(FP-10): 给出 top 贡献特征、方向与临床含义，语言需可被护士理解"
        )

    def stability_check(self, samples: Any, perturbations: int = 20) -> Dict[str, float]:
        """输入轻微扰动下解释排序的一致性。"""
        raise ComponentNotImplementedError(
            "TODO(FP-10): 用秩相关系数衡量稳定性，低于阈值时拒绝输出解释"
        )


__all__ = ["ShapExplainer"]
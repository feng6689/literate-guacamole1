"""特征层：预处理、交互矩阵、特征选择、多项式扩展、目标编码与分布画像。"""

from __future__ import annotations

from .interaction_matrix import InteractionMatrixBuilder, NumpyMatrixGenerator
from .polynomial import PolynomialExpander
from .preprocessor import Preprocessor
from .profiling import DistributionProfiler
from .selectors import UnivariateFSelector
from .target_encoding import OOFWeightEncoder

__all__ = [
    "Preprocessor",
    "InteractionMatrixBuilder",
    "NumpyMatrixGenerator",
    "UnivariateFSelector",
    "PolynomialExpander",
    "OOFWeightEncoder",
    "DistributionProfiler",
]
"""FP-01 / FP-02：患者—事件类型隐式反馈矩阵。"""

from __future__ import annotations

from typing import Any, Dict, Sequence

from ..config import PreprocessConfig
from ..core import ComponentNotImplementedError, DeliverableComponent


class InteractionMatrixBuilder(DeliverableComponent):
    """FP-01：构建隐式反馈风格交互矩阵并施加时间衰减。"""

    fp_id = "FP-01"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "隐式反馈交互矩阵（含时间衰减）",
            "methods": ["build", "apply_time_decay"],
            "acceptance": "行=患者、列=离散事件类型、值=频次，并叠加时间衰减权重",
        }

    def build(self, frame: Any, config: PreprocessConfig) -> Any:
        """行=患者，列=离散化生命体征事件类型，值=频次。"""
        raise ComponentNotImplementedError(
            "TODO(FP-01): 构建稀疏交互矩阵，冻结患者与事件类型索引映射"
        )

    def apply_time_decay(self, matrix: Any, half_life_hours: float) -> Any:
        """按事件距当前时点的间隔施加指数时间衰减。"""
        raise ComponentNotImplementedError(
            "TODO(FP-01): 实现 exp(-lambda*delta_t) 权重并校验随间隔单调递减"
        )


class NumpyMatrixGenerator(DeliverableComponent):
    """FP-02：用 NumPy 生成矩阵并做维度、稀疏性与数值校验。"""

    fp_id = "FP-02"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "NumPy 矩阵生成与校验",
            "methods": ["generate", "apply_log_scaling", "validate_matrix"],
            "acceptance": "维度、稀疏性、数值稳定性（无 NaN/Inf、非负）通过",
        }

    def generate(self, frame: Any, event_type_columns: Sequence[str]) -> Any:
        """从合成记录填充患者—事件类型计数矩阵。"""
        raise ComponentNotImplementedError(
            "TODO(FP-02): 用 NumPy 构建矩阵，保持行顺序稳定并记录非零占比"
        )

    def apply_log_scaling(self, matrix: Any, time_decay: Any) -> Any:
        """对原始计数取 log1p 缩放，再叠加时间衰减权重。"""
        raise ComponentNotImplementedError(
            "TODO(FP-02): 缩放后保持非负与单调性，记录变换参数供 FP-07 打包"
        )

    def validate_matrix(self, matrix: Any) -> Dict[str, Any]:
        """校验维度、稀疏度与数值稳定性。"""
        raise ComponentNotImplementedError(
            "TODO(FP-02): 输出行列数、非零占比、NaN/Inf 计数与最大值"
        )


__all__ = ["InteractionMatrixBuilder", "NumpyMatrixGenerator"]
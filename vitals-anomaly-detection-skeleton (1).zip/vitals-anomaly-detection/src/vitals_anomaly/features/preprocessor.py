"""预处理：缺失值填补、缩放、编码与派生特征。

仅在训练集上拟合，验证/测试集只做 transform；目标编码由 FP-11 的
``OOFWeightEncoder`` 负责，本模块不接触标签。
"""

from __future__ import annotations

from typing import Any

from ..config import PreprocessConfig
from ..core import ComponentNotImplementedError


class Preprocessor:
    """无监督预处理流水线。"""

    def __init__(self) -> None:
        self.fitted_ = False
        self.feature_names_out_: tuple[str, ...] = ()

    def fit(self, train_frame: Any, config: PreprocessConfig) -> "Preprocessor":
        """在训练集上拟合填补、缩放与编码统计量。"""
        raise ComponentNotImplementedError(
            "TODO(preprocess): 拟合中位数/众数、标准化参数与类别映射；禁止使用标签"
        )

    def transform(self, frame: Any) -> Any:
        """应用变换并生成 vitals_delta_rate。"""
        raise ComponentNotImplementedError(
            "TODO(preprocess): 按患者与时间生成相邻快照变化率，确保不使用未来窗口"
        )

    def fit_transform(self, train_frame: Any, config: PreprocessConfig) -> Any:
        """训练集拟合并变换。"""
        raise ComponentNotImplementedError(
            "TODO(preprocess): 组合 fit 与 transform，验证集与测试集只能 transform"
        )


__all__ = ["Preprocessor"]
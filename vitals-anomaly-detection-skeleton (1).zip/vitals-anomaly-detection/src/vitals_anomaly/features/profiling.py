"""FP-08：特征分布画像与异常可分性评估。"""

from __future__ import annotations

from typing import Any, Dict

from ..core import ComponentNotImplementedError, DeliverableComponent


class DistributionProfiler(DeliverableComponent):
    """FP-08：直方图、箱线图、IQR 边界与机构分组比较。"""

    fp_id = "FP-08"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "分布画像与异常叠加",
            "methods": ["profile_numeric", "compare_by_facility", "tabulate"],
            "acceptance": "40 箱直方图、箱线图、IQR 边界，按机构分组比较并输出表格",
        }

    def profile_numeric(self, frame: Any, labels: Any) -> Dict[str, Any]:
        """生成每特征直方图、箱线图与异常类分布叠加。"""
        raise ComponentNotImplementedError(
            "TODO(FP-08): 40 个箱、IQR 越界比例、异常类叠加，图件写入报告目录"
        )

    def compare_by_facility(self, frame: Any, group_column: str) -> Dict[str, Any]:
        """按机构分组比较分布差异。"""
        raise ComponentNotImplementedError(
            "TODO(FP-08): 计算分组均值/方差/分位数并给出差异显著性"
        )

    def tabulate(self, profile: Dict[str, Any]) -> Any:
        """汇总为可交付表格。"""
        raise ComponentNotImplementedError(
            "TODO(FP-08): 输出 CSV/XLSX 表格与图件清单，保持列口径一致"
        )


__all__ = ["DistributionProfiler"]
"""FP-03：单变量 F 统计量特征选择。"""

from __future__ import annotations

from typing import Any, Dict

from ..core import ComponentNotImplementedError, DeliverableComponent


class UnivariateFSelector(DeliverableComponent):
    """FP-03：ANOVA F 检验筛选与噪声稳定性评估。"""

    fp_id = "FP-03"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "单变量 F 统计量特征选择",
            "methods": ["fit", "rank_features", "noise_stability_report"],
            "acceptance": "p<0.01 保留并记录排名，附标签噪声下的排名稳定性",
        }

    def fit(self, features: Any, labels: Any) -> "UnivariateFSelector":
        """计算 F 值与 p 值，默认保留 p < 0.01 的特征。"""
        raise ComponentNotImplementedError(
            "TODO(FP-03): 实现 ANOVA F 检验；记录被剔除特征及 p 值"
        )

    def rank_features(self) -> Any:
        """返回按判别能力降序排列的特征表。"""
        raise ComponentNotImplementedError(
            "TODO(FP-03): 输出排名表并保留与 FP-09 共享的特征顺序"
        )

    def noise_stability_report(self, repetitions: int = 10) -> Dict[str, Any]:
        """在含标签噪声的重采样上评估排名稳定性。"""
        raise ComponentNotImplementedError(
            "TODO(FP-03): 用 top-k Jaccard 重叠或秩相关系数量化稳定性"
        )


__all__ = ["UnivariateFSelector"]
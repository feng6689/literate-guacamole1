"""FP-11：折外目标编码与代理泄漏检测。"""

from __future__ import annotations

from typing import Any, Dict, Sequence

from ..core import ComponentNotImplementedError, DeliverableComponent


class OOFWeightEncoder(DeliverableComponent):
    """FP-11：严格 5 折折外编码，并检测机构/班次代理泄漏。"""

    fp_id = "FP-11"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "折外目标编码",
            "methods": ["fit_transform", "verify_oof", "proxy_leakage_test"],
            "acceptance": "5 折折外，逐折自证无自身标签泄漏，输出代理泄漏量化结果",
        }

    def fit_transform(self, train_frame: Any, columns: Sequence[str], folds: int = 5) -> Any:
        """对 consciousness_score、device_model_code 做折外编码。"""
        raise ComponentNotImplementedError(
            "TODO(FP-11): 每折编码仅使用其余折标签，保留折索引与平滑参数"
        )

    def verify_oof(self, encoded: Any) -> Dict[str, Any]:
        """逐折核对编码是否由本折标签参与计算。"""
        raise ComponentNotImplementedError(
            "TODO(FP-11): 用可复现指纹证明无标签泄漏，输出每折核验结论"
        )

    def proxy_leakage_test(self, encoded: Any, facility: Any) -> Dict[str, float]:
        """检测机构编码、班次编码是否构成代理泄漏。"""
        raise ComponentNotImplementedError(
            "TODO(FP-11): 用互信息或条件熵量化代理性，给出是否剔除的建议"
        )


__all__ = ["OOFWeightEncoder"]
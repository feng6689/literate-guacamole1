"""日志配置工具。"""

from __future__ import annotations

import logging


def configure_logging(level: int = logging.INFO) -> None:
    """统一日志格式与级别，重复调用不会叠加 handler。"""
    root = logging.getLogger()
    root.setLevel(level)
    if root.handlers:
        for handler in root.handlers:
            handler.setLevel(level)
        return
    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    )
    handler.setLevel(level)
    root.addHandler(handler)


def get_logger(name: str) -> logging.Logger:
    """获取带项目前缀的 logger。"""
    return logging.getLogger(f"vitals_anomaly.{name}")


__all__ = ["configure_logging", "get_logger"]
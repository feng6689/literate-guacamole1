"""工程文件清单：确保文档中描述的每个文件都真实存在。

本模块不依赖任何第三方库，可被结构自检脚本、测试与 CI 直接调用。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Tuple

PROJECT_NAME = "vitals-anomaly-detection"
PACKAGE_NAME = "vitals_anomaly"

# manifest.py 位于 <root>/src/vitals_anomaly/manifest.py
PROJECT_ROOT = Path(__file__).resolve().parents[2]

CATEGORY_FILES: Mapping[str, Tuple[str, ...]] = {
    "build": (
        "pyproject.toml",
        "requirements.txt",
        "Makefile",
        ".gitignore",
    ),
    "docs": (
        "README.md",
        "docs/architecture.md",
        "docs/data_contract.md",
        "docs/deliverables.md",
    ),
    "configs": (
        "configs/base.json",
        "configs/debug.json",
    ),
    "core": (
        "src/vitals_anomaly/__init__.py",
        "src/vitals_anomaly/__main__.py",
        "src/vitals_anomaly/cli.py",
        "src/vitals_anomaly/constants.py",
        "src/vitals_anomaly/config.py",
        "src/vitals_anomaly/core.py",
        "src/vitals_anomaly/context.py",
        "src/vitals_anomaly/logging_utils.py",
        "src/vitals_anomaly/manifest.py",
        "src/vitals_anomaly/registry.py",
    ),
    "data": (
        "src/vitals_anomaly/data/__init__.py",
        "src/vitals_anomaly/data/schema.py",
        "src/vitals_anomaly/data/splitter.py",
    ),
    "features": (
        "src/vitals_anomaly/features/__init__.py",
        "src/vitals_anomaly/features/preprocessor.py",
        "src/vitals_anomaly/features/interaction_matrix.py",
        "src/vitals_anomaly/features/selectors.py",
        "src/vitals_anomaly/features/polynomial.py",
        "src/vitals_anomaly/features/target_encoding.py",
        "src/vitals_anomaly/features/profiling.py",
    ),
    "models": (
        "src/vitals_anomaly/models/__init__.py",
        "src/vitals_anomaly/models/bagging.py",
        "src/vitals_anomaly/models/voting.py",
        "src/vitals_anomaly/models/persistence.py",
    ),
    "evaluation": (
        "src/vitals_anomaly/evaluation/__init__.py",
        "src/vitals_anomaly/evaluation/metrics.py",
        "src/vitals_anomaly/evaluation/learning_curve.py",
        "src/vitals_anomaly/evaluation/cross_facility.py",
        "src/vitals_anomaly/evaluation/noise_robustness.py",
        "src/vitals_anomaly/evaluation/fairness.py",
    ),
    "explain": (
        "src/vitals_anomaly/explain/__init__.py",
        "src/vitals_anomaly/explain/shap_explainer.py",
    ),
    "serving": (
        "src/vitals_anomaly/serving/__init__.py",
        "src/vitals_anomaly/serving/service.py",
        "src/vitals_anomaly/serving/drift.py",
    ),
    "pipeline": (
        "src/vitals_anomaly/pipeline/__init__.py",
        "src/vitals_anomaly/pipeline/stages.py",
        "src/vitals_anomaly/pipeline/runner.py",
    ),
    "reporting": (
        "src/vitals_anomaly/reporting/__init__.py",
        "src/vitals_anomaly/reporting/report.py",
    ),
    "scripts": (
        "scripts/check_structure.py",
        "scripts/generate_synthetic_data.py",
        "scripts/run_pipeline.py",
    ),
    "tests": (
        "tests/__init__.py",
        "tests/test_constants.py",
        "tests/test_config.py",
        "tests/test_registry.py",
        "tests/test_structure.py",
        "tests/test_pipeline.py",
    ),
    "placeholders": (
        "data/raw/.gitkeep",
        "artifacts/.gitkeep",
        "reports/.gitkeep",
    ),
}

PROJECT_FILES: Tuple[str, ...] = tuple(
    path for paths in CATEGORY_FILES.values() for path in paths
)
PROJECT_DIRS: Tuple[str, ...] = tuple(
    sorted({str(Path(path).parent) for path in PROJECT_FILES if Path(path).parent != Path(".")})
)


@dataclass(frozen=True)
class ManifestReport:
    """清单核对结果。"""

    root: str
    total: int
    missing_files: Tuple[str, ...]
    missing_dirs: Tuple[str, ...]

    @property
    def ok(self) -> bool:
        return not self.missing_files and not self.missing_dirs

    def to_dict(self) -> Dict[str, object]:
        return {
            "root": self.root,
            "total": self.total,
            "missing_files": list(self.missing_files),
            "missing_dirs": list(self.missing_dirs),
            "ok": self.ok,
        }


def missing_files(root: Path = PROJECT_ROOT, files: Iterable[str] = PROJECT_FILES) -> List[str]:
    """返回磁盘上缺失的文件（相对路径，保持清单顺序）。"""
    return [path for path in files if not (root / path).is_file()]


def missing_dirs(root: Path = PROJECT_ROOT) -> List[str]:
    """返回缺失的目录。"""
    return [path for path in PROJECT_DIRS if not (root / path).is_dir()]


def check_manifest(root: Path = PROJECT_ROOT) -> ManifestReport:
    """生成完整的清单核对报告。"""
    return ManifestReport(
        root=str(root),
        total=len(PROJECT_FILES),
        missing_files=tuple(missing_files(root)),
        missing_dirs=tuple(missing_dirs(root)),
    )
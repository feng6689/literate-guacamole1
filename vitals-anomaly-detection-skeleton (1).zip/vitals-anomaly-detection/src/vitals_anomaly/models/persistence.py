"""FP-07：模型与预处理工件打包、往返校验与降级加载。"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Mapping

from ..core import ComponentNotImplementedError, DeliverableComponent


class ArtifactBundle(DeliverableComponent):
    """FP-07：单一 pickle 包，覆盖集成模型与全部预处理工件。"""

    fp_id = "FP-07"

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "Pickle 打包与往返校验",
            "methods": ["save", "load", "verify_roundtrip", "test_degraded_load"],
            "acceptance": "加载前后预测一致，缺失单个工件时的降级行为可验证",
        }

    def save(
        self,
        path: Path,
        model: Any,
        preprocessor: Any,
        extras: Mapping[str, Any],
    ) -> Path:
        """序列化投票集成、缩放器、编码器、特征选择器与时间衰减参数。"""
        raise ComponentNotImplementedError(
            "TODO(FP-07): 单一 bundle 落盘，写入版本、特征顺序、训练时间与配置摘要"
        )

    def load(self, path: Path) -> Dict[str, Any]:
        """加载 bundle 并校验 schema 版本与特征顺序。"""
        raise ComponentNotImplementedError(
            "TODO(FP-07): 版本不匹配或特征顺序变化时拒绝加载并给出冲突明细"
        )

    def verify_roundtrip(self, path: Path, holdout: Any) -> Dict[str, Any]:
        """加载后预测必须与保存前完全一致。"""
        raise ComponentNotImplementedError(
            "TODO(FP-07): 逐样本比对概率与硬标签，输出最大绝对误差"
        )

    def test_degraded_load(self, path: Path, drop_component: str) -> Dict[str, Any]:
        """缺失单个工件时的降级行为。"""
        raise ComponentNotImplementedError(
            "TODO(FP-07): 定义可降级/必须失败矩阵，输出降级路径与告警"
        )


__all__ = ["ArtifactBundle"]
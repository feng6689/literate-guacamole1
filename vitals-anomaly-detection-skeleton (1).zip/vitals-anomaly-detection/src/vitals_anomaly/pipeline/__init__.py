"""流水线编排：阶段定义与执行器。"""

from __future__ import annotations

from .runner import ProjectPipeline
from .stages import STAGE_PLAN, Stage, covered_fp_ids

__all__ = ["Stage", "STAGE_PLAN", "ProjectPipeline", "covered_fp_ids"]
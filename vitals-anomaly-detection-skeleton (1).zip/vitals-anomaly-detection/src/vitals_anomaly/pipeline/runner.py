"""流水线编排器。"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Dict, Optional

from ..config import PipelineConfig
from ..context import DataBundle, PipelineContext
from ..core import ComponentNotImplementedError
from ..data.schema import SchemaValidator
from ..data.splitter import TemporalSplitter
from ..evaluation.cross_facility import CrossFacilityGeneralizer
from ..evaluation.fairness import FairnessAuditor
from ..evaluation.learning_curve import LearningCurveAnalyzer
from ..evaluation.metrics import HitRateEvaluator
from ..evaluation.noise_robustness import NoiseRobustnessExperiment
from ..explain.shap_explainer import ShapExplainer
from ..features.interaction_matrix import InteractionMatrixBuilder, NumpyMatrixGenerator
from ..features.polynomial import PolynomialExpander
from ..features.preprocessor import Preprocessor
from ..features.profiling import DistributionProfiler
from ..features.selectors import UnivariateFSelector
from ..features.target_encoding import OOFWeightEncoder
from ..models.bagging import BaggingEnsemble
from ..models.persistence import ArtifactBundle
from ..models.voting import SoftVotingEnsemble
from ..serving.service import OnlineScoringService
from .stages import STAGE_PLAN, Stage


class ProjectPipeline:
    """按 STAGE_PLAN 串联数据、特征、模型、评估与交付物组件。"""

    def __init__(self, config: Optional[PipelineConfig] = None) -> None:
        self.config = config or PipelineConfig()
        self.context = PipelineContext(config=self.config)

    def build_components(self) -> Dict[str, Any]:
        """实例化全部阶段组件；组件均为无状态或自带默认配置。"""
        factories: Dict[str, Callable[[], Any]] = {
            "SchemaValidator": SchemaValidator,
            "TemporalSplitter": TemporalSplitter,
            "Preprocessor": Preprocessor,
            "InteractionMatrixBuilder": InteractionMatrixBuilder,
            "NumpyMatrixGenerator": NumpyMatrixGenerator,
            "UnivariateFSelector": UnivariateFSelector,
            "BaggingEnsemble": BaggingEnsemble,
            "SoftVotingEnsemble": SoftVotingEnsemble,
            "HitRateEvaluator": HitRateEvaluator,
            "ArtifactBundle": ArtifactBundle,
            "DistributionProfiler": DistributionProfiler,
            "PolynomialExpander": PolynomialExpander,
            "ShapExplainer": ShapExplainer,
            "OOFWeightEncoder": OOFWeightEncoder,
            "LearningCurveAnalyzer": LearningCurveAnalyzer,
            "CrossFacilityGeneralizer": CrossFacilityGeneralizer,
            "NoiseRobustnessExperiment": NoiseRobustnessExperiment,
            "FairnessAuditor": FairnessAuditor,
            "OnlineScoringService": OnlineScoringService,
        }
        return {name: factory() for name, factory in factories.items()}

    def load_data(self) -> DataBundle:
        """读取原始数据、校验契约并切分。"""
        raise ComponentNotImplementedError(
            "TODO(pipeline): 读取 raw_path，调用 SchemaValidator 与 TemporalSplitter"
        )

    def run_stage(self, stage: Stage) -> Any:
        """执行单个阶段，并把结果写入上下文。"""
        raise ComponentNotImplementedError(
            "TODO(pipeline): 依据 Stage 定义调度组件方法，记录耗时与失败回滚点"
        )

    def run(self) -> PipelineContext:
        """按顺序执行全部阶段。"""
        raise ComponentNotImplementedError(
            "TODO(pipeline): 逐阶段执行，任一阶段失败即停止并保留已完成产物"
        )

    def export_report(self, path: Path) -> Path:
        """导出运行报告。"""
        raise ComponentNotImplementedError(
            "TODO(report): 汇总指标、图件与审计结论，附可追溯证据路径"
        )


__all__ = ["ProjectPipeline", "STAGE_PLAN"]
"""流水线阶段定义与覆盖检查。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Set, Tuple


@dataclass(frozen=True)
class Stage:
    """一个可独立执行与校验的阶段。"""

    name: str
    component: str
    action: str
    fp_ids: Tuple[str, ...] = ()


STAGE_PLAN: Tuple[Stage, ...] = (
    Stage("schema", "SchemaValidator", "validate"),
    Stage("split", "TemporalSplitter", "split"),
    Stage("preprocess", "Preprocessor", "fit_transform", ("FP-11",)),
    Stage("interaction_matrix", "InteractionMatrixBuilder", "build", ("FP-01",)),
    Stage("matrix_generation", "NumpyMatrixGenerator", "generate", ("FP-02",)),
    Stage("feature_selection", "UnivariateFSelector", "fit", ("FP-03",)),
    Stage("bagging", "BaggingEnsemble", "fit", ("FP-04",)),
    Stage("soft_voting", "SoftVotingEnsemble", "fit", ("FP-05",)),
    Stage("hit_rate", "HitRateEvaluator", "hit_rate_at_k", ("FP-06",)),
    Stage("bundle", "ArtifactBundle", "verify_roundtrip", ("FP-07",)),
    Stage("distribution", "DistributionProfiler", "profile_numeric", ("FP-08",)),
    Stage("polynomial", "PolynomialExpander", "expand", ("FP-09",)),
    Stage("shap", "ShapExplainer", "global_importance", ("FP-10",)),
    Stage("oof_encoding", "OOFWeightEncoder", "fit_transform", ("FP-11",)),
    Stage("learning_curve", "LearningCurveAnalyzer", "compute", ("FP-12",)),
    Stage("cross_facility", "CrossFacilityGeneralizer", "leave_one_facility_out", ("FP-13",)),
    Stage("noise_robustness", "NoiseRobustnessExperiment", "run", ("FP-14",)),
    Stage("fairness", "FairnessAuditor", "group_metrics", ("FP-15",)),
    Stage("online_serving", "OnlineScoringService", "serve", ("FP-16",)),
)

STAGE_BY_NAME: Dict[str, Stage] = {stage.name: stage for stage in STAGE_PLAN}


def covered_fp_ids() -> Set[str]:
    """返回阶段计划覆盖的 FP 编号集合。"""
    return {fp_id for stage in STAGE_PLAN for fp_id in stage.fp_ids}


def stage_component_names() -> Set[str]:
    """返回阶段引用到的组件类名集合。"""
    return {stage.component for stage in STAGE_PLAN}


__all__ = ["Stage", "STAGE_PLAN", "STAGE_BY_NAME", "covered_fp_ids", "stage_component_names"]
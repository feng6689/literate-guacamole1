"""FP-01 ~ FP-16 交付物注册表。

注册表只保存模块路径、类名与方法名，不做模块级导入，避免循环依赖；
``resolve`` 与 ``check_registry`` 在调用时才解析并校验。
"""

from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Tuple

from .core import DeliverableComponent, RegistryError


@dataclass(frozen=True)
class DeliverableSpec:
    """一条交付物登记项。"""

    fp_id: str
    title: str
    module: str
    component: str
    entry_method: str
    acceptance: str


DELIVERABLES: Tuple[DeliverableSpec, ...] = (
    DeliverableSpec("FP-01", "隐式反馈交互矩阵（含时间衰减）",
                    "vitals_anomaly.features.interaction_matrix",
                    "InteractionMatrixBuilder", "build",
                    "行=患者、列=离散事件类型、值=频次，并叠加时间衰减权重"),
    DeliverableSpec("FP-02", "NumPy 矩阵生成与校验",
                    "vitals_anomaly.features.interaction_matrix",
                    "NumpyMatrixGenerator", "generate",
                    "维度、稀疏性、数值稳定性通过"),
    DeliverableSpec("FP-03", "单变量 F 统计量特征选择",
                    "vitals_anomaly.features.selectors",
                    "UnivariateFSelector", "fit",
                    "p<0.01 保留并记录排名，附噪声稳定性"),
    DeliverableSpec("FP-04", "Bagging 集成",
                    "vitals_anomaly.models.bagging",
                    "BaggingEnsemble", "fit",
                    "≥200 棵树，max_samples=0.75，max_features=0.6，报告 OOB"),
    DeliverableSpec("FP-05", "软投票集成（代价敏感）",
                    "vitals_anomaly.models.voting",
                    "SoftVotingEnsemble", "fit",
                    "≥3 个异构成员，权重搜索最大化命中率"),
    DeliverableSpec("FP-06", "Hit Rate@K 评估",
                    "vitals_anomaly.evaluation.metrics",
                    "HitRateEvaluator", "hit_rate_at_k",
                    "K=5/10/20/50，自助 95% CI，分层报告"),
    DeliverableSpec("FP-07", "Pickle 打包与往返校验",
                    "vitals_anomaly.models.persistence",
                    "ArtifactBundle", "save",
                    "加载前后预测一致，缺失工件可降级"),
    DeliverableSpec("FP-08", "分布画像与异常叠加",
                    "vitals_anomaly.features.profiling",
                    "DistributionProfiler", "profile_numeric",
                    "40 箱直方图、箱线图、IQR 边界、机构分组"),
    DeliverableSpec("FP-09", "多项式扩展与剪枝",
                    "vitals_anomaly.features.polynomial",
                    "PolynomialExpander", "expand",
                    "前 8 特征 degree=2，剪枝后仅保留增益项"),
    DeliverableSpec("FP-10", "SHAP 解释与稳定性检验",
                    "vitals_anomaly.explain.shap_explainer",
                    "ShapExplainer", "global_importance",
                    "全局条形图、蜂群图、局部解释与稳定性"),
    DeliverableSpec("FP-11", "折外目标编码",
                    "vitals_anomaly.features.target_encoding",
                    "OOFWeightEncoder", "fit_transform",
                    "5 折折外，逐折自证无标签泄漏，检测代理泄漏"),
    DeliverableSpec("FP-12", "学习曲线",
                    "vitals_anomaly.evaluation.learning_curve",
                    "LearningCurveAnalyzer", "compute",
                    "10%~100% 共 10 档，诊断偏差-方差并判断收敛"),
    DeliverableSpec("FP-13", "跨机构泛化",
                    "vitals_anomaly.evaluation.cross_facility",
                    "CrossFacilityGeneralizer", "leave_one_facility_out",
                    "留一机构 AP 衰减、校准与重加权方案"),
    DeliverableSpec("FP-14", "标签噪声鲁棒性实验",
                    "vitals_anomaly.evaluation.noise_robustness",
                    "NoiseRobustnessExperiment", "run",
                    "2% 标签噪声下对比三种损失并给推荐"),
    DeliverableSpec("FP-15", "公平性审计",
                    "vitals_anomaly.evaluation.fairness",
                    "FairnessAuditor", "group_metrics",
                    "机构/年龄/性别分组差异判定与缓解建议"),
    DeliverableSpec("FP-16", "在线评分与漂移监测",
                    "vitals_anomaly.serving.service",
                    "OnlineScoringService", "serve",
                    "500 条/批、300ms 预算、PSI 超阈值降级"),
)

DELIVERABLE_BY_ID: Dict[str, DeliverableSpec] = {spec.fp_id: spec for spec in DELIVERABLES}


def resolve(spec: DeliverableSpec) -> Tuple[type, Callable[..., Any]]:
    """解析交付物组件类与入口方法，失败时抛 RegistryError。"""
    try:
        module = importlib.import_module(spec.module)
    except ImportError as exc:
        raise RegistryError(f"{spec.fp_id}: 无法导入模块 {spec.module}: {exc}") from exc
    component = getattr(module, spec.component, None)
    if component is None:
        raise RegistryError(f"{spec.fp_id}: 模块 {spec.module} 缺少类 {spec.component}")
    if not isinstance(component, type) or not issubclass(component, DeliverableComponent):
        raise RegistryError(f"{spec.fp_id}: {spec.component} 未继承 DeliverableComponent")
    method = getattr(component, spec.entry_method, None)
    if method is None or not callable(method):
        raise RegistryError(f"{spec.fp_id}: {spec.component} 缺少方法 {spec.entry_method}")
    return component, method


def check_registry() -> Dict[str, Any]:
    """逐条解析交付物，返回结构化自检报告。"""
    rows: List[Dict[str, Any]] = []
    problems: List[str] = []
    for spec in DELIVERABLES:
        row: Dict[str, Any] = {
            "fp": spec.fp_id,
            "title": spec.title,
            "module": spec.module,
            "component": spec.component,
            "entry": spec.entry_method,
        }
        try:
            component, method = resolve(spec)
            row["resolved"] = True
            row["declared_fp"] = getattr(component, "fp_id", None)
            row["callable"] = callable(method)
            if row["declared_fp"] != spec.fp_id:
                problems.append(
                    f"{spec.fp_id}: 组件声明为 {row['declared_fp']}，与登记不一致"
                )
        except RegistryError as exc:
            row["resolved"] = False
            problems.append(str(exc))
        rows.append(row)
    return {
        "ok": not problems,
        "count": len(DELIVERABLES),
        "problems": problems,
        "deliverables": rows,
    }


__all__ = [
    "DeliverableSpec", "DELIVERABLES", "DELIVERABLE_BY_ID", "resolve", "check_registry",
]
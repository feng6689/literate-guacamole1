"""报告层。"""

from __future__ import annotations

from .report import ReportWriter

__all__ = ["ReportWriter"]
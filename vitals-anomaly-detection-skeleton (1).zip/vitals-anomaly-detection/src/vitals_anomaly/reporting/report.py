"""报告输出：运行摘要与结构化报告。"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from ..context import PipelineContext
from ..core import ComponentNotImplementedError


class ReportWriter:
    """把运行摘要与指标写为 JSON，并预留 Markdown 报告接口。"""

    def write_json(self, context: PipelineContext, path: Path) -> Path:
        """写出可机读的运行摘要。"""
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(context.summary(), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return target

    def build_markdown(self, context: PipelineContext) -> str:
        """生成面向临床与工程双方的 Markdown 报告。"""
        raise ComponentNotImplementedError(
            "TODO(report): 包含数据概况、主指标、分层结果、公平性结论与局限说明"
        )

    def write_markdown(self, context: PipelineContext, path: Path) -> Path:
        """写出 Markdown 报告。"""
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(self.build_markdown(context), encoding="utf-8")
        return target


__all__ = ["ReportWriter"]
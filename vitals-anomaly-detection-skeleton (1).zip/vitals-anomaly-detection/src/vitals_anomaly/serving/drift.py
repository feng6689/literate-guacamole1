"""FP-16：在线特征漂移监测。"""

from __future__ import annotations

from typing import Any, Dict, Mapping

from ..config import ServingConfig
from ..core import ComponentNotImplementedError, DeliverableComponent


class DriftMonitor(DeliverableComponent):
    """FP-16：PSI 漂移监测、告警分级与重训练触发。"""

    fp_id = "FP-16"

    def __init__(self, config: ServingConfig | None = None) -> None:
        self.config = config or ServingConfig()

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "漂移监测与降级告警",
            "methods": ["compute_psi", "watch", "trigger_alert"],
            "acceptance": "逐特征 PSI、滑动窗口趋势、超阈值告警与冷却机制",
        }

    def compute_psi(self, reference: Any, current: Any, bins: int = 10) -> Dict[str, float]:
        """逐特征计算 PSI。"""
        raise ComponentNotImplementedError(
            "TODO(FP-16): 处理零频分箱与最小样本量，避免除零导致 PSI 虚高"
        )

    def watch(self, batch: Any) -> Dict[str, Any]:
        """滚动窗口监测并记录漂移趋势。"""
        raise ComponentNotImplementedError(
            "TODO(FP-16): 维护参考分布与滑动窗口，输出告警等级与受影响特征"
        )

    def trigger_alert(self, psi: Mapping[str, float]) -> Dict[str, Any]:
        """超阈值时触发降级或重训练告警。"""
        raise ComponentNotImplementedError(
            "TODO(FP-16): 加入冷却窗口、升级路径与人工确认门槛，禁止自动重训练"
        )


__all__ = ["DriftMonitor"]
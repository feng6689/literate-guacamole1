"""FP-16：在线批量评分服务。"""

from __future__ import annotations

from typing import Any, Dict, Iterable, Sequence

from ..config import ServingConfig
from ..core import ComponentNotImplementedError, DeliverableComponent


class OnlineScoringService(DeliverableComponent):
    """FP-16：每批 500 条、端到端 300ms 预算的在线评分。"""

    fp_id = "FP-16"

    def __init__(self, bundle: Any = None, config: ServingConfig | None = None) -> None:
        self.bundle = bundle
        self.config = config or ServingConfig()

    def describe(self) -> Dict[str, Any]:
        return {
            "title": "在线推理服务",
            "methods": ["score_batch", "serve", "check_latency_budget"],
            "acceptance": "500 条/批、端到端 P95 低于 300ms，漂移超阈值可降级",
        }

    def score_batch(self, batch: Any) -> Any:
        """输出概率、硬标签与解释摘要。"""
        raise ComponentNotImplementedError(
            "TODO(FP-16): 保证批内顺序稳定，缺失特征走降级路径并记录原因"
        )

    def serve(self, stream: Iterable[Any]) -> Any:
        """流式消费并按批评分。"""
        raise ComponentNotImplementedError(
            "TODO(FP-16): 接入 DriftMonitor，异常时熔断或切换兜底模型"
        )

    def check_latency_budget(self, observed_ms: Sequence[float]) -> Dict[str, Any]:
        """统计 P50/P95/P99 与超限比例，判断是否满足延迟预算。"""
        values = sorted(float(item) for item in observed_ms)
        budget = self.config.latency_budget_ms
        if not values:
            return {"ok": False, "reason": "无延迟样本", "budget_ms": budget}

        def quantile(p: float) -> float:
            index = min(len(values) - 1, max(0, int(round((len(values) - 1) * p))))
            return values[index]

        over = sum(1 for value in values if value > budget) / len(values)
        p95 = quantile(0.95)
        return {
            "ok": p95 <= budget,
            "budget_ms": budget,
            "p50_ms": quantile(0.50),
            "p95_ms": p95,
            "p99_ms": quantile(0.99),
            "over_budget_ratio": over,
            "n_samples": len(values),
        }


__all__ = ["OnlineScoringService"]
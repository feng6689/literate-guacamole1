"""配置加载、导出与校验测试。"""

from __future__ import annotations

import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from vitals_anomaly.config import PipelineConfig

ROOT = Path(__file__).resolve().parents[1]


class ConfigTest(unittest.TestCase):
    def test_base_config_is_valid(self) -> None:
        config = PipelineConfig.from_json(ROOT / "configs/base.json")
        self.assertEqual(config.validate(), [])
        self.assertEqual(config.bagging.n_estimators, 200)
        self.assertEqual(config.evaluation.hit_rate_ks, (5, 10, 20, 50))
        self.assertIsInstance(config.data.raw_path, Path)
        self.assertEqual(config.serving.batch_size, 500)

    def test_debug_config_is_valid(self) -> None:
        config = PipelineConfig.from_json(ROOT / "configs/debug.json")
        self.assertEqual(config.validate(), [])
        self.assertEqual(config.bagging.n_estimators, 20)
        self.assertEqual(config.evaluation.hit_rate_ks, (5, 10))

    def test_dict_roundtrip(self) -> None:
        config = PipelineConfig.from_json(ROOT / "configs/base.json")
        restored = PipelineConfig.from_dict(config.to_dict())
        self.assertEqual(restored.to_dict(), config.to_dict())

    def test_json_roundtrip(self) -> None:
        config = PipelineConfig.from_json(ROOT / "configs/base.json")
        with tempfile.TemporaryDirectory() as tmp:
            target = config.to_json(Path(tmp) / "copy.json")
            payload = json.loads(target.read_text(encoding="utf-8"))
            self.assertEqual(payload["evaluation"]["ap_target"], 0.78)
            restored = PipelineConfig.from_json(target)
        self.assertEqual(restored.to_dict(), config.to_dict())

    def test_invalid_split_detected(self) -> None:
        config = PipelineConfig()
        broken = replace(
            config, data=replace(config.data, test_size=0.9, validation_size=0.2)
        )
        issues = broken.validate()
        self.assertTrue(any("test_size" in issue or "训练集比例" in issue for issue in issues))

    def test_invalid_estimator_detected(self) -> None:
        config = PipelineConfig()
        broken = replace(config, bagging=replace(config.bagging, n_estimators=0))
        self.assertTrue(any("n_estimators" in issue for issue in broken.validate()))


if __name__ == "__main__":
    unittest.main()
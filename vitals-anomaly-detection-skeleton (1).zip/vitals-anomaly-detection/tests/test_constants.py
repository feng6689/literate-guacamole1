"""契约常量与特征规格测试。"""

from __future__ import annotations

import unittest

from vitals_anomaly import constants


class FeatureContractTest(unittest.TestCase):
    def test_feature_count_and_uniqueness(self) -> None:
        self.assertEqual(len(constants.FEATURE_SPECS), constants.N_INPUT_FEATURES)
        self.assertEqual(len(set(constants.FEATURE_NAMES)), constants.N_INPUT_FEATURES)

    def test_contract_is_self_consistent(self) -> None:
        report = constants.validate_feature_contract()
        self.assertTrue(report["ok"], report["issues"])
        self.assertEqual(report["numeric"], 18)
        self.assertEqual(report["ordinal"], 1)
        self.assertEqual(report["categorical"], 3)

    def test_target_and_group_excluded_from_features(self) -> None:
        self.assertNotIn(constants.TARGET_COLUMN, constants.FEATURE_NAMES)
        self.assertNotIn(constants.GROUP_COLUMN, constants.FEATURE_NAMES)
        self.assertEqual(len(constants.REQUIRED_COLUMNS), 26)

    def test_project_targets(self) -> None:
        self.assertEqual(constants.N_RECORDS, 68_000)
        self.assertAlmostEqual(constants.POSITIVE_RATE, 0.018)
        self.assertAlmostEqual(constants.ARTIFACT_RATE, 0.03)
        self.assertAlmostEqual(constants.LABEL_NOISE_RATE, 0.02)
        self.assertAlmostEqual(constants.AP_TARGET, 0.78)
        self.assertAlmostEqual(constants.HIT_RATE_TARGET, 0.92)
        self.assertEqual(constants.HIT_RATE_KS, (5, 10, 20, 50))
        self.assertEqual(constants.BATCH_SIZE, 500)
        self.assertAlmostEqual(constants.LATENCY_BUDGET_MS, 300.0)

    def test_derived_feature_not_in_raw_features(self) -> None:
        for name in constants.DERIVED_FEATURES:
            self.assertNotIn(name, constants.FEATURE_NAMES)
        self.assertIn("vitals_delta_rate", constants.MONITORED_DRIFT_FEATURES)


if __name__ == "__main__":
    unittest.main()
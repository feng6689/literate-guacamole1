"""流水线阶段、组件实例化与报告输出测试。"""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from vitals_anomaly.config import PipelineConfig
from vitals_anomaly.context import PipelineContext
from vitals_anomaly.pipeline.runner import ProjectPipeline
from vitals_anomaly.pipeline.stages import STAGE_PLAN, covered_fp_ids
from vitals_anomaly.reporting.report import ReportWriter


class PipelineTest(unittest.TestCase):
    def test_stage_plan_covers_all_deliverables(self) -> None:
        expected = {f"FP-{index:02d}" for index in range(1, 17)}
        self.assertEqual(covered_fp_ids(), expected)
        self.assertEqual(len(STAGE_PLAN), 19)

    def test_components_are_instances(self) -> None:
        components = ProjectPipeline(PipelineConfig()).build_components()
        self.assertEqual(len(components), 19)
        for name, component in components.items():
            self.assertFalse(isinstance(component, type), name)
            self.assertTrue(hasattr(component, "__class__"), name)

    def test_run_is_not_implemented(self) -> None:
        with self.assertRaises(NotImplementedError):
            ProjectPipeline().run()

    def test_report_writer_outputs_json(self) -> None:
        context = PipelineContext(config=PipelineConfig())
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "summary.json"
            written = ReportWriter().write_json(context, target)
            payload = json.loads(written.read_text(encoding="utf-8"))
        self.assertIn("elapsed_seconds", payload)
        self.assertIsNone(payload["data_sizes"])
        self.assertEqual(payload["metrics"], {})


if __name__ == "__main__":
    unittest.main()
"""交付物注册表测试。"""

from __future__ import annotations

import unittest

from vitals_anomaly.core import DeliverableComponent
from vitals_anomaly.registry import (
    DELIVERABLES,
    DELIVERABLE_BY_ID,
    check_registry,
    resolve,
)


class RegistryTest(unittest.TestCase):
    def test_sixteen_unique_deliverables(self) -> None:
        self.assertEqual(len(DELIVERABLES), 16)
        expected = {f"FP-{index:02d}" for index in range(1, 17)}
        self.assertEqual(set(DELIVERABLE_BY_ID), expected)

    def test_registry_resolves(self) -> None:
        report = check_registry()
        self.assertTrue(report["ok"], report["problems"])
        self.assertEqual(report["count"], 16)

    def test_components_inherit_base_and_match_fp(self) -> None:
        for spec in DELIVERABLES:
            component, method = resolve(spec)
            self.assertTrue(issubclass(component, DeliverableComponent))
            self.assertEqual(component.fp_id, spec.fp_id)
            self.assertTrue(callable(method))

    def test_describe_contract(self) -> None:
        for spec in DELIVERABLES:
            component, _ = resolve(spec)
            description = component().describe()
            self.assertIn("title", description)
            self.assertIn("methods", description)
            self.assertIn(spec.entry_method, description["methods"])


if __name__ == "__main__":
    unittest.main()
"""工程结构、文件清单与 CLI 测试。"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import unittest
from pathlib import Path

from vitals_anomaly.manifest import CATEGORY_FILES, PROJECT_FILES, check_manifest
from vitals_anomaly.pipeline.runner import ProjectPipeline
from vitals_anomaly.pipeline.stages import STAGE_PLAN, stage_component_names

ROOT = Path(__file__).resolve().parents[1]


class StructureTest(unittest.TestCase):
    def test_manifest_files_exist(self) -> None:
        report = check_manifest(ROOT)
        self.assertTrue(report.ok, f"missing files={report.missing_files}, dirs={report.missing_dirs}")
        self.assertEqual(report.total, 62)
        self.assertEqual(len(PROJECT_FILES), 62)
        self.assertEqual(len(set(PROJECT_FILES)), 62)

    def test_category_count_matches_manifest(self) -> None:
        self.assertEqual(sum(len(paths) for paths in CATEGORY_FILES.values()), 62)

    def test_stage_plan_components_exist(self) -> None:
        self.assertEqual(len(STAGE_PLAN), 19)
        self.assertEqual(len({stage.name for stage in STAGE_PLAN}), 19)
        components = ProjectPipeline().build_components()
        self.assertEqual(stage_component_names(), set(components))

    def test_cli_check_structure_passes(self) -> None:
        env = dict(os.environ)
        env["PYTHONPATH"] = str(ROOT / "src")
        completed = subprocess.run(
            [sys.executable, "-m", "vitals_anomaly", "check-structure"],
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        payload = json.loads(completed.stdout)
        self.assertTrue(payload["ok"], payload)
        self.assertTrue(payload["manifest"]["ok"])
        self.assertTrue(payload["registry"]["ok"])


if __name__ == "__main__":
    unittest.main()